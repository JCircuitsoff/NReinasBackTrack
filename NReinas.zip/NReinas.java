import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Locale;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;
import java.text.NumberFormat;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.imageio.ImageIO;

/**
 * ============================================================================
 *  N REINAS · Explorador visual de backtracking (Java Swing)
 * ============================================================================
 *  Requiere JDK 17 o superior (usa records, switch-expressions y text blocks).
 *
 *  REPRESENTACIÓN
 *  --------------
 *  int[] reinas = new int[N];
 *     índice  = fila
 *     valor   = columna donde está la reina de esa fila (-1 = fila sin reina)
 *  columnaPor[columna] guarda la fila que ocupa una columna.
 *  diagonalPor y antidiagonalPor registran la fila que ocupa cada diagonal.
 *  Los tres arreglos auxiliares permiten detectar ataques en tiempo O(1).
 *  Ejemplo N=4, solución: [1, 3, 0, 2]
 *  Al guardar una reina por fila (índice), no hay conflictos entre filas;
 *  solo hay que revisar columnas y diagonales contra las filas anteriores.
 *
 *  RECORRIDO Y ANIMACIÓN
 *  ---------------------
 *  resolver(fila) ejecuta la búsqueda recursiva y registra instantáneas de cada
 *  paso. Swing reproduce esas instantáneas con sus temporizadores; durante la
 *  reproducción, la interfaz avanza el historial sin repetir la búsqueda.
 *
 *  ----------------------------------------------------------------------------
 *  CASOS BORDE
 *  ----------------------------------------------------------------------------
 *  N = 1  (solución inmediata)
 *     resolver(0): evalúa (0,0). No hay reinas previas, el ciclo de conflictos
 *     no itera, no hay conflicto -> coloca. resolver(1) cumple fila == N y
 *     devuelve true. Resultado [0]. Son 3 pasos y cero retrocesos.
 *
 *  N = 2  (sin solución)
 *     Fila 0, col 0: ok. Fila 1: col 0 (misma columna) y col 1 (diagonal) fallan
 *     -> la fila 1 agota sus columnas, retrocede. Fila 0, col 1: ok. Fila 1:
 *     col 0 (diagonal) y col 1 (misma columna) fallan -> retrocede. Fila 0
 *     agota sus 2 columnas: resolver(0) devuelve false. Termina normalmente.
 *
 *  N = 3  (sin solución)
 *     Cada una de las 3 posiciones de la fila 0 se explora; en todas, la fila 1
 *     tiene a lo sumo una casilla libre y esa casilla deja a la fila 2 sin
 *     ninguna columna válida. Se retrocede hasta la fila 0 y se agota el árbol.
 *     Termina devolviendo false (no es un error ni una excepción).
 *
 *  Idea común: "no hay solución" es una respuesta válida del algoritmo; ocurre
 *  cuando el ciclo for de la fila 0 se agota. El backtracking siempre termina
 *  porque el árbol de búsqueda es finito (profundidad N, ramificación <= N).
 *
 *  ----------------------------------------------------------------------------
 *  ANÁLISIS DE COMPLEJIDAD (Big O)
 *  ----------------------------------------------------------------------------
 *  TIEMPO
 *   Un nodo del árbol de búsqueda = un estado parcial con k reinas colocadas.
 *   Como las columnas no pueden repetirse, en el nivel k hay a lo sumo
 *        N * (N-1) * ... * (N-k+1) = N! / (N-k)!   nodos.
 *   Total de nodos:
 *        T(N) = SUM_{k=0..N} N!/(N-k)! = N! * SUM_{j=0..N} 1/j!  <=  e * N!
 *   (porque la suma de 1/j! converge a e ~ 2.718). Por tanto T(N) = O(N!).
 *   Para N=4 la cota da 1+4+12+24+24 = 65 nodos como máximo.
 *   - PEOR CASO: O(N * N!). El árbol tiene O(N!) estados parciales y cada
 *     estado puede evaluar hasta N columnas. Los arreglos auxiliares permiten
 *     comprobar columna y diagonales en O(1) por candidata.
 *   - PROMEDIO: no hay un promedio único sin definir una distribución de tamaños
 *     y ejecuciones. O(N * N!) se presenta como cota superior, no como promedio.
 *   - MEJOR RECORRIDO: si se completa una ruta sin retrocesos y se evalúa un
 *     número constante de candidatas por fila, el trabajo es O(N). Si se prueban
 *     hasta N candidatas en cada fila de esa ruta, es O(N^2). No se garantiza
 *     ninguno de esos recorridos para todo tamaño N.
 *
 *  ESPACIO: O(N)
 *   - reinas[], el registro de columnas y los dos registros diagonales ocupan
 *     O(N) posiciones en total.
 *   - La pila de recursión llega a profundidad N+1 (una llamada por fila), con
 *     variables locales de tamaño constante: O(N).
 *   - Total del algoritmo: O(N) + O(N) = O(N). El árbol no se guarda:
 *     se recorre y se deshace (reinas[fila] = -1 al retroceder).
 *   - La animación sí conserva instantáneas: con S eventos ocupa O(S*N)
 *     posiciones de tablero, además de los mensajes. Es memoria de la interfaz,
 *     no del algoritmo recursivo.
 * ============================================================================
 */
public class NReinas extends JFrame {

    // ------------------------------------------------------------------ tipos
    enum Tipo { INICIO, EVALUANDO, COLOCADA, CONFLICTO, RETROCESO, SOLUCION, SIN_SOLUCION }

    record PaletaTablero(String nombre, Color clara, Color oscura) { }

    private static final List<PaletaTablero> PALETAS = List.of(
            new PaletaTablero("Clásica", new Color(0xEEEED2), new Color(0x769656)),
            new PaletaTablero("Océano", new Color(0xDCEFF2), new Color(0x397A91)),
            new PaletaTablero("Atardecer", new Color(0xF7E4D1), new Color(0xA45B78)),
            new PaletaTablero("Medianoche", new Color(0xD8D9E8), new Color(0x4B4D75)));

    /** Estado inmutable del tablero en un paso de la animación. */
    record Estado(int n, int[] reinas, String[] nombresReinas, Tipo tipo, int fila, int col,
                  int otraFila, int otraCol, String mensaje, String codigo, int paso,
                  int intentos, int conflictos, int retrocesos) { }

    private record EstadoDuelo(int[][] tablero, int turno, int ganador, String mensaje) { }

    // ----------------------------------------------------------------- colores
    static final Color CASILLA_CLARA = new Color(0xEEEED2);
    static final Color CASILLA_OSCURA = new Color(0x769656);
    static final Color NARANJA = new Color(0xF4A261);
    static final Color VERDE = new Color(0xB7E4C7);
    static final Color ROJO = new Color(0xD1495B);
    static final Color AZUL_OSCURO = new Color(0x172554);
    static final Color FONDO = new Color(0xF3F0E7);
    private static final List<String> NOMBRES_REINAS = List.of(
            "Hatshepsut — Egipto",
            "Cleopatra VII — Egipto ptolemaico",
            "Nefertiti — Egipto",
            "Amanirenas — reino de Kush (actual Sudán)",
            "Zenobia — Palmira (actual Siria)",
            "Boudica — pueblo iceno, Britania (actual Inglaterra)",
            "Nzinga Mbande — Ndongo y Matamba (actual Angola)",
            "Amina de Zazzau — Zazzau (actual Nigeria)",
            "Seondeok — reino de Silla (actual Corea)",
            "Tamar la Grande — Georgia",
            "Isabel I — Inglaterra",
            "Isabel II — Reino Unido",
            "Victoria — Reino Unido",
            "Artemisia I — Halicarnaso (actual Turquía)",
            "Razia Sultan — Sultanato de Delhi (actual India)",
            "Lakshmibai — Jhansi (actual India)",
            "María I Tudor — Inglaterra",
            "Isabel I de Castilla — Castilla (actual España)",
            "María I de Escocia — Escocia",
            "Urraca I — León (actual España)",
            "Ku-Baba — Kish (actual Irak)",
            "Puabi — Ur (actual Irak)",
            "Shibtu — Mari (actual Siria)",
            "Ahhotep I — Egipto",
            "Ahmose-Nefertari — Egipto",
            "Tiye — Egipto",
            "Nefertari — Egipto",
            "Meritamen — Egipto",
            "Ankhesenamun — Egipto",
            "Arsinoe I — Egipto ptolemaico",
            "Arsinoe II — Egipto ptolemaico",
            "Berenice I — Egipto ptolemaico",
            "Berenice II — Cirene y Egipto ptolemaico",
            "Cleopatra I Syra — Egipto ptolemaico",
            "Cleopatra II — Egipto ptolemaico",
            "Cleopatra III — Egipto ptolemaico",
            "Cleopatra Selene II — Mauritania",
            "Amanishakheto — reino de Kush (actual Sudán)",
            "Shanakdakhete — reino de Kush (actual Sudán)",
            "Nawidemak — reino de Kush (actual Sudán)",
            "Puduhepa — reino hitita (actual Turquía)",
            "Tomiris — reino de los masagetas (Asia Central)",
            "Atosa — Imperio aqueménida (actual Irán)",
            "Parisátide — Imperio aqueménida (actual Irán)",
            "Musa — Imperio parto (actual Irán)",
            "Mavia — confederación tanújida (Arabia)",
            "Olimpia de Epiro — Epiro y Macedonia",
            "Eurídice II de Macedonia — Macedonia",
            "Cinanê — Macedonia",
            "Cleopatra de Macedonia — Macedonia",
            "Julia Domna — Imperio romano",
            "Livia Drusila — Imperio romano",
            "Agripina la Menor — Imperio romano",
            "Gala Placidia — Imperio romano de Occidente",
            "Amalasunta — reino ostrogodo de Italia",
            "Brunegilda — reino franco de Austrasia",
            "Fredegunda — reino franco de Neustria",
            "Irene de Atenas — Imperio bizantino",
            "Zoe Porfirogéneta — Imperio bizantino",
            "Teodora Porfirogéneta — Imperio bizantino",
            "María de Alania — Imperio bizantino",
            "Rusudán de Georgia — reino de Georgia",
            "Ketevan de Kajetia — reino de Kajetia (actual Georgia)",
            "Olga de Kiev — Rus de Kiev (actual Ucrania)",
            "Ana de Kiev — Rus de Kiev (actual Ucrania)",
            "Gudit — reino de Axum (actual Etiopía)",
            "Mentewab — Imperio etíope",
            "Zewditu — Imperio etíope",
            "Taytu Betul — Imperio etíope",
            "Ranavalona I — reino de Madagascar",
            "Ranavalona II — reino de Madagascar",
            "Ranavalona III — reino de Madagascar",
            "Yaa Asantewaa — reino ashanti (actual Ghana)",
            "Sarraounia Mangou — reino azna (actual Níger)",
            "Nandi kaBhebhe — reino zulú (actual Sudáfrica)",
            "Dihya — reino amazigh de Aurés (actual Argelia)",
            "Arwa al-Sulayhi — dinastía sulayhí (actual Yemen)",
            "Shajar al-Durr — sultanato mameluco de Egipto",
            "Sitt al-Mulk — califato fatimí de Egipto",
            "Didda — reino de Cachemira (actual India)",
            "Naiki Devi — reino de Gujarat (actual India)",
            "Rudrama Devi — reino Kakatiya (actual India)",
            "Rani Durgavati — reino de Gondwana (actual India)",
            "Ahilyabai Holkar — reino de Indore (actual India)",
            "Kittur Chennamma — reino de Kittur (actual India)",
            "Velu Nachiyar — reino de Sivaganga (actual India)",
            "Chand Bibi — sultanato de Ahmadnagar (actual India)",
            "Nur Jahan — Imperio mogol (actual India)",
            "Tribhuwana Wijayatunggadewi — reino de Majapahit (actual Indonesia)",
            "Suhita — reino de Majapahit (actual Indonesia)",
            "Ratu Kalinyamat — Jepara (actual Indonesia)",
            "Shin Sawbu — reino de Hanthawaddy (actual Myanmar)",
            "Pwa Saw — reino de Pagan (actual Myanmar)",
            "Suriyothai — reino de Ayutthaya (actual Tailandia)",
            "Saovabha Phongsri — reino de Siam (actual Tailandia)",
            "Sisowath Kossamak — Camboya",
            "Jayarajadevi — imperio jemer (actual Camboya)",
            "Indradevi — imperio jemer (actual Camboya)",
            "Trung Trac — Lĩnh Nam (actual Vietnam)",
            "Trung Nhi — Lĩnh Nam (actual Vietnam)",
            "Jindeok — reino de Silla (actual Corea)",
            "Jinseong — reino de Silla (actual Corea)",
            "Suiko — Japón",
            "Kōgyoku — Japón",
            "Jitō — Japón",
            "Genmei — Japón",
            "Genshō — Japón",
            "Kōken — Japón",
            "Meishō — Japón",
            "Go-Sakuramachi — Japón",
            "Himiko — Yamatai (actual Japón)",
            "Fu Hao — dinastía Shang (actual China)",
            "Lü Zhi — dinastía Han (actual China)",
            "Wu Zetian — China",
            "Xiaozhuang — dinastía Qing (actual China)",
            "Cixi — dinastía Qing (actual China)",
            "Reina Xuan — estado de Qin (actual China)",
            "Yohl Ikʼnal — Palenque (actual México)",
            "Ix Kʼabel — reino maya de Wakaʼ (actual Guatemala)",
            "Tzʼak-bʼu Ajaw — Palenque (actual México)",
            "Lady Six Sky — reino maya de Naranjo (actual Guatemala)",
            "Lady Kʼawiil Ajaw — Coba (actual México)",
            "Liliʻuokalani — reino de Hawái",
            "Emma Kalanikaumakaʻamano Kaleleonālani — reino de Hawái",
            "Kaʻahumanu — reino de Hawái",
            "Ana de Bretaña — Bretaña y Francia",
            "Blanca de Castilla — Francia",
            "Leonor de Provenza — Francia",
            "Catalina de Médici — Francia",
            "Isabel de Baviera — Francia",
            "Margarita de Valois — Francia",
            "Matilde de Flandes — Inglaterra",
            "Edith de Wessex — Inglaterra",
            "Matilde de Escocia — Inglaterra",
            "Leonor de Aquitania — Inglaterra",
            "Berenguela de Navarra — Inglaterra",
            "Isabel de Angulema — Inglaterra",
            "Isabel de Francia — Inglaterra",
            "Felipa de Henao — Inglaterra",
            "Isabel Woodville — Inglaterra",
            "Ana Neville — Inglaterra",
            "Isabel de York — Inglaterra",
            "Catalina de Aragón — Inglaterra",
            "Ana Bolena — Inglaterra",
            "Jane Seymour — Inglaterra",
            "Ana de Cléveris — Inglaterra",
            "Catalina Howard — Inglaterra",
            "Catalina Parr — Inglaterra",
            "María II — Inglaterra y Escocia",
            "Ana Estuardo — Gran Bretaña",
            "Wilhelmina — Países Bajos",
            "Juliana — Países Bajos",
            "Beatriz — Países Bajos",
            "Emma de Waldeck y Pyrmont — Países Bajos",
            "Jadwiga — Polonia",
            "Bona Sforza — Polonia y Lituania",
            "Ana Jagellón — Polonia",
            "Margarita I — Dinamarca, Noruega y Suecia",
            "Cristina — Suecia",
            "Ulrica Leonor — Suecia",
            "Catalina II — Imperio ruso",
            "Isabel Petrovna — Imperio ruso",
            "Ana Ioánnovna — Imperio ruso",
            "María I — Portugal",
            "María II — Portugal",
            "Juana I — Castilla y Aragón",
            "Petronila — reino de Aragón",
            "Sancha Raimúndez — reino de León",
            "María de Molina — reino de Castilla",
            "Berenguela I — reino de Castilla",
            "Toda Aznárez — reino de Navarra",
            "Isabel II — España");
    private static final int MAXIMO_NOMBRES_POR_SIMULACION = 113;
    static {
        if (new HashSet<>(NOMBRES_REINAS).size() != NOMBRES_REINAS.size()) {
            throw new ExceptionInInitializerError("El catálogo contiene identidades históricas repetidas.");
        }
        if (NOMBRES_REINAS.size() < MAXIMO_NOMBRES_POR_SIMULACION) {
            throw new ExceptionInInitializerError("El catálogo no cubre todos los movimientos de N=8.");
        }
    }
    static final BufferedImage ICONO_REINA = cargarIconoReina();

    private static String resumenNombresReinas(String[] nombres) {
        StringBuilder resumen = new StringBuilder(
                "IDENTIDADES VISUALES · personaje y territorio");
        int cantidad = 0;
        for (int fila = 0; fila < nombres.length; fila++) {
            if (nombres[fila] == null) continue;
            resumen.append("\nFila ").append(fila + 1).append("  ·  ").append(nombres[fila]);
            cantidad++;
        }
        if (cantidad == 0) resumen.append("\nAún no hay piezas colocadas.");
        else resumen.append("\nLos nombres se asignan al azar y no se reutilizan durante esta búsqueda, ni siquiera al retroceder.")
                .append("\nSon etiquetas visuales: no afectan las reglas ni la solución.");
        return resumen.toString();
    }

    private static BufferedImage cargarIconoReina() {
        try (InputStream entrada = NReinas.class.getResourceAsStream("/reina.png")) {
            if (entrada == null) {
                throw new IllegalStateException("No se encontró reina.png junto al programa.");
            }
            BufferedImage original = ImageIO.read(entrada);
            if (original == null) throw new IOException("El archivo reina.png no es una imagen válida.");

            int anchoOriginal = original.getWidth(), altoOriginal = original.getHeight();
            int[] pixeles = original.getRGB(0, 0, anchoOriginal, altoOriginal, null, 0, anchoOriginal);
            int superiorIzquierdo = pixeles[0];
            int superiorDerecho = pixeles[anchoOriginal - 1];
            int inferiorIzquierdo = pixeles[(altoOriginal - 1) * anchoOriginal];
            int inferiorDerecho = pixeles[pixeles.length - 1];
            int fondoR = (((superiorIzquierdo >>> 16) & 0xFF) + ((superiorDerecho >>> 16) & 0xFF)
                    + ((inferiorIzquierdo >>> 16) & 0xFF) + ((inferiorDerecho >>> 16) & 0xFF)) / 4;
            int fondoG = (((superiorIzquierdo >>> 8) & 0xFF) + ((superiorDerecho >>> 8) & 0xFF)
                    + ((inferiorIzquierdo >>> 8) & 0xFF) + ((inferiorDerecho >>> 8) & 0xFF)) / 4;
            int fondoB = ((superiorIzquierdo & 0xFF) + (superiorDerecho & 0xFF)
                    + (inferiorIzquierdo & 0xFF) + (inferiorDerecho & 0xFF)) / 4;
            boolean[] fondoConectado = new boolean[pixeles.length];
            int[] pendientes = new int[pixeles.length];
            int siguiente = 0;
            for (int x = 0; x < anchoOriginal; x++) {
                siguiente = marcarFondo(x, pixeles, fondoConectado, pendientes, siguiente,
                        fondoR, fondoG, fondoB);
                int inferior = (altoOriginal - 1) * anchoOriginal + x;
                siguiente = marcarFondo(inferior, pixeles, fondoConectado, pendientes, siguiente,
                        fondoR, fondoG, fondoB);
            }
            for (int y = 1; y < altoOriginal - 1; y++) {
                siguiente = marcarFondo(y * anchoOriginal, pixeles, fondoConectado, pendientes, siguiente,
                        fondoR, fondoG, fondoB);
                siguiente = marcarFondo(y * anchoOriginal + anchoOriginal - 1,
                        pixeles, fondoConectado, pendientes, siguiente, fondoR, fondoG, fondoB);
            }
            for (int cabeza = 0; cabeza < siguiente; cabeza++) {
                int indice = pendientes[cabeza];
                int x = indice % anchoOriginal;
                if (x > 0) siguiente = marcarFondo(indice - 1, pixeles, fondoConectado,
                        pendientes, siguiente, fondoR, fondoG, fondoB);
                if (x + 1 < anchoOriginal) siguiente = marcarFondo(indice + 1, pixeles,
                        fondoConectado, pendientes, siguiente, fondoR, fondoG, fondoB);
                if (indice >= anchoOriginal) siguiente = marcarFondo(indice - anchoOriginal,
                        pixeles, fondoConectado, pendientes, siguiente, fondoR, fondoG, fondoB);
                if (indice + anchoOriginal < pixeles.length) siguiente = marcarFondo(
                        indice + anchoOriginal, pixeles, fondoConectado, pendientes, siguiente,
                        fondoR, fondoG, fondoB);
            }

            int minX = anchoOriginal, minY = altoOriginal, maxX = -1, maxY = -1;
            for (int indice = 0; indice < pixeles.length; indice++) {
                int alpha = pixeles[indice] >>> 24;
                if (alpha == 0) continue;
                if (fondoConectado[indice]) {
                    int rojo = (pixeles[indice] >>> 16) & 0xFF;
                    int verde = (pixeles[indice] >>> 8) & 0xFF;
                    int azul = pixeles[indice] & 0xFF;
                    int diferencia = Math.max(Math.abs(rojo - fondoR),
                            Math.max(Math.abs(verde - fondoG), Math.abs(azul - fondoB)));
                    alpha = diferencia <= 6 ? 0 : alpha * diferencia / Math.max(fondoR, Math.max(fondoG, fondoB));
                }
                if (alpha == 0) continue;
                int x = indice % anchoOriginal, y = indice / anchoOriginal;
                minX = Math.min(minX, x);
                minY = Math.min(minY, y);
                maxX = Math.max(maxX, x);
                maxY = Math.max(maxY, y);
            }
            if (maxX < minX || maxY < minY) throw new IOException("reina.png no contiene una silueta visible.");

            int ancho = maxX - minX + 1, alto = maxY - minY + 1;
            int[] pixelesRecorte = new int[ancho * alto];
            for (int y = minY; y <= maxY; y++) {
                for (int x = minX; x <= maxX; x++) {
                    int indice = y * anchoOriginal + x;
                    int pixel = pixeles[indice];
                    int alpha = pixel >>> 24;
                    if (fondoConectado[indice]) {
                        int rojo = (pixel >>> 16) & 0xFF;
                        int verde = (pixel >>> 8) & 0xFF;
                        int azul = pixel & 0xFF;
                        int diferencia = Math.max(Math.abs(rojo - fondoR),
                                Math.max(Math.abs(verde - fondoG), Math.abs(azul - fondoB)));
                        alpha = diferencia <= 6 ? 0
                                : alpha * diferencia / Math.max(fondoR, Math.max(fondoG, fondoB));
                    }
                    pixelesRecorte[(y - minY) * ancho + x - minX] = alpha << 24 | 0x003B3025;
                }
            }
            BufferedImage recorte = new BufferedImage(ancho, alto, BufferedImage.TYPE_INT_ARGB);
            recorte.setRGB(0, 0, ancho, alto, pixelesRecorte, 0, ancho);

            BufferedImage icono = new BufferedImage(512, 512, BufferedImage.TYPE_INT_ARGB);
            Graphics2D g = icono.createGraphics();
            g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
            g.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
            g.setRenderingHint(RenderingHints.KEY_ALPHA_INTERPOLATION, RenderingHints.VALUE_ALPHA_INTERPOLATION_QUALITY);
            g.setRenderingHint(RenderingHints.KEY_COLOR_RENDERING, RenderingHints.VALUE_COLOR_RENDER_QUALITY);
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            int altura = 460;
            int anchoIcono = (int) Math.round((double) recorte.getWidth() * altura / recorte.getHeight());
            g.drawImage(recorte, (512 - anchoIcono) / 2, (512 - altura) / 2,
                    anchoIcono, altura, null);
            g.dispose();
            return icono;
        } catch (IOException e) {
            throw new ExceptionInInitializerError(e);
        }
    }

    private static int marcarFondo(int indice, int[] pixeles, boolean[] fondoConectado,
                                   int[] pendientes, int siguiente, int fondoR, int fondoG, int fondoB) {
        int pixel = pixeles[indice];
        if (fondoConectado[indice] || (pixel >>> 24) == 0
                || Math.abs(((pixel >>> 16) & 0xFF) - fondoR) > 24
                || Math.abs(((pixel >>> 8) & 0xFF) - fondoG) > 24
                || Math.abs((pixel & 0xFF) - fondoB) > 24) return siguiente;
        fondoConectado[indice] = true;
        pendientes[siguiente++] = indice;
        return siguiente;
    }

    // ---------------------------------------------------------- componentes UI
    private final Tablero tablero = new Tablero();
    private final RepresentacionReinas representacionReinas = new RepresentacionReinas();
    private final JLabel lblPaso = new JLabel("Listo para comenzar", SwingConstants.CENTER);
    private final JLabel lblTableroEstado = new JLabel("4 × 4");
    private final JLabel lblRetoProgreso = new JLabel("REINAS COLOCADAS");
    private final JProgressBar barraProgreso = new JProgressBar(0, 4);
    private final JLabel lblMetricas = new JLabel("0 intentos  ·  0 conflictos  ·  0 retrocesos");
    private final JLabel lblNComplejidad = new JLabel("N = 4", SwingConstants.CENTER);
    private final JLabel lblEstadosCota = new JLabel("65", SwingConstants.CENTER);
    private final JLabel lblIntentosCota = new JLabel("260", SwingConstants.CENTER);
    private final JLabel lblAhorroPoda = new JLabel("—", SwingConstants.CENTER);
    private final JTextArea lblActividadComplejidad = new JTextArea(
            "Ejecuta la búsqueda para comparar sus intentos con la cota superior.", 2, 45);
    private Estado ultimoEstadoPrincipal;
    private PanelGraficoComplejidad graficoComplejidad;
    private final JTextArea txtExplicacion = new JTextArea();
    private final JTextArea txtCodigo = new JTextArea();
    private final JEditorPane resumenCaso = new JEditorPane("text/html",
            "<html><body>Elige un tablero para comparar su recorrido y resultado.</body></html>");
    private final JButton btnSiguiente = new JButton("Siguiente paso");
    private final JButton btnAnterior = new JButton("← Anterior");
    private final JButton btnReiniciar = new JButton("Reiniciar");
    private final JButton btnAuto = new JButton("▶ Reproducir");
    private final JButton btnPresentar = new JButton("⛶ Presentar");
    private final JToggleButton btnRangos = new JToggleButton("Rangos de ataque", true);
    private final JComboBox<Integer> cmbN = new JComboBox<>(new Integer[]{1, 2, 3, 4, 5, 6, 7, 8});
    private final JComboBox<String> cmbRitmo = new JComboBox<>(
            new String[]{"Lento", "Normal", "Rápido", "Muy rápido"});
    private final JComboBox<String> cmbPaleta = new JComboBox<>(
            PALETAS.stream().map(PaletaTablero::nombre).toArray(String[]::new));
    private final Timer temporizador = new Timer(850, e -> avanzar());
    private final JTabbedPane tabs = new JTabbedPane();
    private JComponent vistaAnimacion;
    private JSlider sliderComplejidad;
    private MiniSimulacion miniSimulacion;
    private DueloReinas dueloReinas;
    private final JButton[] botonesCasos = new JButton[4];
    private JLabel[] etiquetasPestanas;
    private int casoSeleccionado = -1;

    private Ejecucion ejecucion;
    private Estado estadoInicioPrincipal;
    private int selectorNComplejidad = 4;
    private boolean accionesReveladas;

    public NReinas() {
        super("N Reinas · Explorador de backtracking");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout(12, 12));
        getContentPane().setBackground(FONDO);
        ((JComponent) getContentPane()).setBorder(new EmptyBorder(16, 18, 16, 18));
        add(crearEncabezado(), BorderLayout.NORTH);
        add(crearPanelDerecho(), BorderLayout.CENTER);

        cmbN.setSelectedItem(4);
        cmbN.addActionListener(e -> reiniciar());
        btnReiniciar.addActionListener(e -> reiniciar());
        btnSiguiente.addActionListener(e -> avanzar());
        btnAnterior.addActionListener(e -> retrocederPaso());
        btnAuto.addActionListener(e -> alternarReproduccion());
        btnPresentar.addActionListener(e -> alternarModoPresentacion());
        btnRangos.addActionListener(e -> actualizarRangosAtaque());
        cmbRitmo.addActionListener(e -> actualizarRitmo());
        cmbPaleta.addActionListener(e -> aplicarPaleta());
        actualizarRangosAtaque();
        aplicarPaleta();
        instalarAtajosTeclado();
        tabs.setSelectedIndex(0);

        setMinimumSize(new Dimension(980, 650));
        Rectangle pantalla = GraphicsEnvironment.getLocalGraphicsEnvironment().getMaximumWindowBounds();
        setSize(Math.min(1420, Math.max(980, pantalla.width - 28)),
                Math.min(900, Math.max(650, pantalla.height - 28)));
        setLocationRelativeTo(null);
        reiniciar();
    }

    private void alternarModoPresentacion() {
        if ((getExtendedState() & JFrame.MAXIMIZED_BOTH) == JFrame.MAXIMIZED_BOTH) {
            setExtendedState(JFrame.NORMAL);
            btnPresentar.setText("Presentar");
        } else {
            setExtendedState(JFrame.MAXIMIZED_BOTH);
            btnPresentar.setText("Volver");
        }
    }

    private void instalarAtajosTeclado() {
        InputMap input = getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW);
        ActionMap actions = getRootPane().getActionMap();
        input.put(KeyStroke.getKeyStroke("SPACE"), "avanzar-paso");
        input.put(KeyStroke.getKeyStroke("LEFT"), "retroceder-paso");
        input.put(KeyStroke.getKeyStroke('M'), "cambiar-ritmo");
        input.put(KeyStroke.getKeyStroke("H"), "alternar-rangos");
        actions.put("avanzar-paso", new AbstractAction() {
            @Override public void actionPerformed(java.awt.event.ActionEvent e) {
                if (tabs.getSelectedIndex() == 1 && miniSimulacion != null) miniSimulacion.avanzar();
                else avanzar();
            }
        });
        actions.put("retroceder-paso", new AbstractAction() {
            @Override public void actionPerformed(java.awt.event.ActionEvent e) {
                if (tabs.getSelectedIndex() == 1 && miniSimulacion != null) miniSimulacion.retroceder();
                else retrocederPaso();
            }
        });
        actions.put("cambiar-ritmo", new AbstractAction() {
            @Override public void actionPerformed(java.awt.event.ActionEvent e) {
                cmbRitmo.setSelectedIndex((cmbRitmo.getSelectedIndex() + 1) % cmbRitmo.getItemCount());
            }
        });
        actions.put("alternar-rangos", new AbstractAction() {
            @Override public void actionPerformed(java.awt.event.ActionEvent e) {
                btnRangos.setSelected(!btnRangos.isSelected());
                actualizarRangosAtaque();
            }
        });
    }

    private void actualizarRangosAtaque() {
        tablero.setHeatmapActivo(btnRangos.isSelected());
        if (miniSimulacion != null) miniSimulacion.setHeatmapActivo(btnRangos.isSelected());
        btnRangos.setText(btnRangos.isSelected() ? "Rangos: activos" : "Rangos: ocultos");
        btnRangos.setBackground(btnRangos.isSelected()
                ? new Color(0xEAF3F0) : new Color(0xF1F0E6));
    }

    private PaletaTablero paletaSeleccionada() {
        return PALETAS.get(cmbPaleta.getSelectedIndex());
    }

    private void aplicarPaleta() {
        PaletaTablero paleta = paletaSeleccionada();
        tablero.setPaleta(paleta);
        if (miniSimulacion != null) miniSimulacion.setPaleta(paleta);
        if (dueloReinas != null) dueloReinas.setPaleta(paleta);
    }

    private JComponent crearEscenarioTablero() {
        JPanel escenario = new JPanel(new BorderLayout(0, 8));
        escenario.setBackground(new Color(0xE4E9DD));
        escenario.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(0xC6D5CC)),
                new EmptyBorder(10, 10, 10, 10)));

        JPanel cabecera = new JPanel(new BorderLayout(8, 3));
        cabecera.setBackground(new Color(0x173B35));
        cabecera.setBorder(new EmptyBorder(10, 12, 10, 12));
        JLabel titulo = new JLabel("TABLERO DE BÚSQUEDA");
        titulo.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 17));
        titulo.setForeground(new Color(0xFFF4D6));
        lblTableroEstado.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 13));
        lblTableroEstado.setForeground(new Color(0xC8E6D5));
        cabecera.add(titulo, BorderLayout.WEST);
        cabecera.add(lblTableroEstado, BorderLayout.EAST);

        JPanel lienzo = new JPanel(new BorderLayout());
        lienzo.setBackground(new Color(0xF1F0E6));
        lienzo.setBorder(new EmptyBorder(8, 8, 8, 8));
        lienzo.add(tablero, BorderLayout.CENTER);

        escenario.add(cabecera, BorderLayout.NORTH);
        escenario.add(lienzo, BorderLayout.CENTER);
        JPanel leyenda = new JPanel(new GridLayout(1, 3, 6, 4));
        leyenda.setOpaque(false);
        leyenda.add(itemLeyenda(NARANJA, AZUL_OSCURO, "Candidata"));
        leyenda.add(itemLeyenda(VERDE, AZUL_OSCURO, "Reina colocada"));
        leyenda.add(itemLeyenda(ROJO, Color.WHITE, "Conflicto / retroceso"));
        escenario.add(leyenda, BorderLayout.SOUTH);
        return escenario;
    }

    private JComponent crearEncabezado() {
        JPanel encabezado = new JPanel(new BorderLayout(12, 4));
        encabezado.setOpaque(true);
        encabezado.setBackground(new Color(0xF1E8D5));
        encabezado.setBorder(new EmptyBorder(9, 12, 9, 12));
        JLabel titulo = new JLabel("N REINAS");
        titulo.setIcon(new ImageIcon(ICONO_REINA.getScaledInstance(34, 34, Image.SCALE_SMOOTH)));
        titulo.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 25));
        titulo.setForeground(AZUL_OSCURO);
        JLabel subtitulo = new JLabel("Una búsqueda visual: probar, comprobar y retroceder");
        subtitulo.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 14));
        subtitulo.setForeground(new Color(0x5D6255));
        JPanel textos = new JPanel(new GridLayout(0, 1, 2, 2));
        textos.setOpaque(false);
        textos.add(titulo);
        textos.add(subtitulo);
        encabezado.add(textos, BorderLayout.CENTER);
        JPanel estadoPresentacion = new JPanel();
        estadoPresentacion.setOpaque(false);
        estadoPresentacion.setLayout(new BorderLayout(0, 5));
        JLabel etiquetaPaleta = new JLabel("Paleta");
        etiquetaPaleta.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 12));
        etiquetaPaleta.setForeground(new Color(0x526078));
        JPanel selectorPaleta = new JPanel(new FlowLayout(FlowLayout.RIGHT, 6, 0));
        selectorPaleta.setOpaque(false);
        selectorPaleta.add(etiquetaPaleta);
        selectorPaleta.add(cmbPaleta);
        estadoPresentacion.add(selectorPaleta, BorderLayout.NORTH);
        lblPaso.setOpaque(true);
        lblPaso.setBackground(new Color(0x173B35));
        lblPaso.setForeground(new Color(0xF7F1E3));
        lblPaso.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 14));
        lblPaso.setHorizontalAlignment(SwingConstants.CENTER);
        lblPaso.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(0x526944)),
                new EmptyBorder(9, 13, 9, 13)));
        estadoPresentacion.add(lblPaso, BorderLayout.CENTER);
        encabezado.add(estadoPresentacion, BorderLayout.EAST);
        return encabezado;
    }

    // ------------------------------------------------------------ construcción UI
    private JComponent crearPanelDerecho() {
        JPanel filaPrincipal = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 3));
        filaPrincipal.setOpaque(false);
        JPanel filaOpciones = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 3));
        filaOpciones.setOpaque(false);
        JLabel etiquetaN = new JLabel("♟  TABLERO N");
        etiquetaN.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 13));
        etiquetaN.setForeground(new Color(0x263A2B));
        etiquetaN.setToolTipText("Elige el tamaño del tablero y el número de reinas.");
        cmbN.setToolTipText("Tamaño del tablero y número de reinas que se deben ubicar.");
        btnSiguiente.setToolTipText("Avanza un paso del recorrido. Atajo: Espacio.");
        btnAuto.setToolTipText("Reproduce o pausa la secuencia de eventos.");
        btnReiniciar.setToolTipText("Vuelve al tablero vacío y genera un nuevo recorrido.");
        btnPresentar.setToolTipText("Alterna entre ventana normal y pantalla completa.");
        btnAnterior.setToolTipText("Revisa el paso anterior. Atajo: flecha izquierda.");
        estilizarBoton(btnAnterior, new Color(0x625D50));
        btnRangos.setToolTipText("Al pasar sobre una reina, resalta su fila, columna y diagonales. Atajo: H.");
        cmbPaleta.setToolTipText("Cambia los colores de los tableros del explorador y del duelo.");
        btnRangos.setSelected(true);
        JLabel ritmo = new JLabel("Ritmo");
        ritmo.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 13));
        ritmo.setForeground(new Color(0x526078));
        cmbRitmo.setSelectedItem("Normal");
        cmbRitmo.setToolTipText("Ajusta la velocidad de reproducción. Atajo: M.");
        btnSiguiente.setText("Siguiente paso  →");
        estilizarBoton(btnSiguiente, new Color(0x385E3B));
        btnAuto.setToolTipText("Reproduce o pausa la secuencia; el selector Velocidad cambia el ritmo.");
        estilizarBoton(btnAuto, new Color(0x173B35));
        estilizarBoton(btnReiniciar, new Color(0x625D50));
        estilizarBoton(btnPresentar, new Color(0x9A6A24));
        estilizarSelector(cmbN, 14);
        estilizarSelector(cmbRitmo, 12);
        estilizarSelector(cmbPaleta, 12);
        btnRangos.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 13));
        btnRangos.setForeground(new Color(0x173B35));
        btnRangos.setBackground(new Color(0xEAF3F0));
        btnRangos.setOpaque(true);
        btnRangos.setFocusPainted(false);
        btnRangos.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(0xB9D0C2)),
                new EmptyBorder(7, 10, 7, 10)));
        btnRangos.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        filaPrincipal.add(crearGrupoControles("Tablero", etiquetaN, cmbN));
        filaPrincipal.add(crearGrupoControles("Recorrido",
                btnSiguiente, btnAnterior, btnAuto, btnReiniciar));
        filaOpciones.add(crearGrupoControles("Visualización", btnRangos, btnPresentar));
        filaOpciones.add(crearGrupoControles("Velocidad", ritmo, cmbRitmo));
        JPanel controles = new JPanel(new GridLayout(2, 1, 0, 3));
        controles.setOpaque(true);
        controles.setBackground(Color.WHITE);
        controles.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(0xD8E0DA)),
                new EmptyBorder(4, 8, 4, 8)));
        controles.add(filaPrincipal);
        controles.add(filaOpciones);

        representacionReinas.setPreferredSize(new Dimension(400, 92));
        lblMetricas.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 13));
        lblMetricas.setForeground(AZUL_OSCURO);
        lblMetricas.setOpaque(true);
        lblMetricas.setBackground(new Color(0xEAF3F0));
        lblMetricas.setBorder(new EmptyBorder(8, 10, 8, 10));
        lblMetricas.setHorizontalAlignment(SwingConstants.CENTER);
        lblMetricas.setToolTipText("Intentos: candidatas examinadas. Conflictos: candidatas descartadas. Retrocesos: decisiones retiradas al agotarse una rama.");


        txtExplicacion.setEditable(false);
        txtExplicacion.setLineWrap(true);
        txtExplicacion.setWrapStyleWord(true);
        txtExplicacion.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 16));
        txtExplicacion.setMargin(new Insets(13, 14, 13, 14));
        JScrollPane scroll = new JScrollPane(txtExplicacion);
        scroll.setBorder(BorderFactory.createTitledBorder("¿Qué está ocurriendo?"));

        txtCodigo.setEditable(false);
        txtCodigo.setLineWrap(true);
        txtCodigo.setWrapStyleWord(true);
        txtCodigo.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 15));
        txtCodigo.setForeground(new Color(0xE2E8F0));
        txtCodigo.setBackground(new Color(0x172033));
        txtCodigo.setMargin(new Insets(10, 11, 10, 11));
        JScrollPane scrollCodigo = new JScrollPane(txtCodigo);
        scrollCodigo.setBorder(BorderFactory.createTitledBorder("Código relacionado"));
        scrollCodigo.setToolTipText("Fragmento de búsqueda relacionado con el evento actual.");
        scroll.setToolTipText("Qué está evaluando el algoritmo y por qué toma esta decisión.");

        JPanel centro = new JPanel(new BorderLayout(6, 6));
        centro.setOpaque(false);
        centro.setPreferredSize(new Dimension(510, 620));
        JPanel estadoTablero = new JPanel(new BorderLayout(5, 5));
        estadoTablero.setOpaque(false);
        estadoTablero.add(representacionReinas, BorderLayout.CENTER);
        estadoTablero.add(lblMetricas, BorderLayout.SOUTH);
        centro.add(estadoTablero, BorderLayout.NORTH);
        JSplitPane explicacionCodigo = new JSplitPane(JSplitPane.VERTICAL_SPLIT, scroll, scrollCodigo);
        explicacionCodigo.setResizeWeight(0.58);
        explicacionCodigo.setBorder(null);
        explicacionCodigo.setContinuousLayout(true);
        centro.add(explicacionCodigo, BorderLayout.CENTER);

        JPanel paginaAnimacion = new JPanel(new BorderLayout(8, 8));
        paginaAnimacion.setBackground(new Color(0xF1F0E6));
        paginaAnimacion.setBorder(new EmptyBorder(10, 10, 10, 10));
        JComponent escenario = crearEscenarioTablero();
        escenario.setMinimumSize(new Dimension(470, 360));
        centro.setMinimumSize(new Dimension(390, 360));
        JSplitPane division = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, escenario, centro);
        division.setContinuousLayout(true);
        division.setOneTouchExpandable(true);
        division.setResizeWeight(0.57);
        division.setDividerSize(10);
        fijarDivisorAlPrimerLayout(division, 0.55);
        fijarDivisorAlPrimerLayout(explicacionCodigo, 0.58);
        JPanel encabezadoAnimacion = new JPanel(new BorderLayout(0, 6));
        encabezadoAnimacion.setOpaque(false);
        encabezadoAnimacion.add(controles, BorderLayout.NORTH);
        JPanel contextoAnimacion = new JPanel(new BorderLayout());
        contextoAnimacion.setOpaque(false);
        contextoAnimacion.add(crearPanelReto(), BorderLayout.NORTH);
        encabezadoAnimacion.add(contextoAnimacion, BorderLayout.CENTER);
        paginaAnimacion.add(encabezadoAnimacion, BorderLayout.NORTH);
        paginaAnimacion.add(division, BorderLayout.CENTER);

        tabs.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 15));
        tabs.setTabLayoutPolicy(JTabbedPane.SCROLL_TAB_LAYOUT);
        vistaAnimacion = paginaAnimacion;
        tabs.addTab("01 · Animación", vistaAnimacion);
        tabs.addTab("02 · Casos y ejemplos", crearPanelCasos());
        tabs.addTab("03 · Big O", crearPanelComplejidad());
        tabs.addTab("04 · Pseudocódigo", crearPanelTexto(PSEUDOCODIGO));
        tabs.addTab("05 · Créditos", crearPanelTexto(FUENTES_CREDITOS));
        tabs.addTab("06 · Duelo de reinas", crearPanelDuelo());
        estilizarPestanas();
        tabs.setPreferredSize(new Dimension(1200, 720));
        tabs.setMinimumSize(new Dimension(900, 500));
        return tabs;
    }

    private JPanel crearGrupoControles(String titulo, Component... componentes) {
        JPanel grupo = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 3));
        grupo.setOpaque(true);
        grupo.setBackground(new Color(0xFBFAF5));
        grupo.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(new Color(0xD8E0DA)),
                titulo, javax.swing.border.TitledBorder.LEFT,
                javax.swing.border.TitledBorder.TOP,
                new Font(Font.SANS_SERIF, Font.BOLD, 11),
                new Color(0x526944)));
        for (Component componente : componentes) grupo.add(componente);
        return grupo;
    }

    private void actualizarRitmo() {
        int demora = switch (cmbRitmo.getSelectedItem().toString()) {
            case "Lento" -> 1400;
            case "Rápido" -> 350;
            case "Muy rápido" -> 180;
            default -> 850;
        };
        temporizador.setDelay(demora);
        temporizador.setInitialDelay(demora);
        if (miniSimulacion != null) miniSimulacion.setRitmo(demora);
    }

    private void retrocederPaso() {
        if (ejecucion == null || estadoInicioPrincipal == null) return;
        detenerReproduccion();
        Estado anterior = ejecucion.estadoAnterior(estadoInicioPrincipal);
        if (anterior != null) mostrar(anterior);
    }

    private void fijarDivisorAlPrimerLayout(JSplitPane divisor, double proporcion) {
        divisor.setResizeWeight(proporcion);
        divisor.addComponentListener(new java.awt.event.ComponentAdapter() {
            private boolean inicializado;

            private void ajustar() {
                if (inicializado || !divisor.isShowing()
                        || divisor.getWidth() <= 0 || divisor.getHeight() <= 0) return;
                inicializado = true;
                divisor.setDividerLocation(proporcion);
                divisor.removeComponentListener(this);
            }

            @Override
            public void componentShown(java.awt.event.ComponentEvent evento) {
                ajustar();
            }

            @Override
            public void componentResized(java.awt.event.ComponentEvent evento) {
                ajustar();
            }
        });
    }

    private void estilizarPestanas() {
        tabs.setOpaque(true);
        tabs.setBackground(Color.WHITE);
        tabs.setForeground(AZUL_OSCURO);
        tabs.setBorder(BorderFactory.createMatteBorder(0, 0, 2, 0, new Color(0xCBD5E1)));
        etiquetasPestanas = new JLabel[tabs.getTabCount()];
        for (int i = 0; i < tabs.getTabCount(); i++) {
            JLabel etiqueta = new JLabel(tabs.getTitleAt(i), SwingConstants.CENTER);
            etiqueta.setOpaque(true);
            etiqueta.setBorder(new EmptyBorder(10, 14, 10, 14));
            etiqueta.setToolTipText("Abrir sección: " + tabs.getTitleAt(i));
            etiqueta.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            int indice = i;
            etiqueta.addMouseListener(new java.awt.event.MouseAdapter() {
                @Override
                public void mousePressed(java.awt.event.MouseEvent evento) {
                    tabs.setSelectedIndex(indice);
                }

                @Override
                public void mouseEntered(java.awt.event.MouseEvent evento) {
                    if (tabs.getSelectedIndex() != indice) etiqueta.setBackground(new Color(0xE4E9DD));
                }

                @Override
                public void mouseExited(java.awt.event.MouseEvent evento) {
                    if (tabs.getSelectedIndex() != indice) etiqueta.setBackground(new Color(0xF1F0E6));
                }
            });
            etiquetasPestanas[i] = etiqueta;
            tabs.setTabComponentAt(i, etiqueta);
        }
        tabs.addChangeListener(event -> actualizarEstiloPestanas());
        actualizarEstiloPestanas();
    }

    private void actualizarEstiloPestanas() {
        if (etiquetasPestanas == null) return;
        for (int i = 0; i < etiquetasPestanas.length; i++) {
            JLabel etiqueta = etiquetasPestanas[i];
            boolean seleccionada = i == tabs.getSelectedIndex();
            etiqueta.setBackground(seleccionada ? new Color(0x173B35) : new Color(0xF1F0E6));
            etiqueta.setForeground(seleccionada ? new Color(0xFFF4D6) : AZUL_OSCURO);
            etiqueta.setFont(new Font(Font.SANS_SERIF,
                    seleccionada ? Font.BOLD : Font.PLAIN, 15));
            etiqueta.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createMatteBorder(0, 0, seleccionada ? 3 : 0, 0,
                            seleccionada ? new Color(0xF4A261) : new Color(0xCBD5E1)),
                    new EmptyBorder(10, 14, 10, 14)));
        }
    }

    private void estilizarSelector(JComboBox<?> selector, int tamanoFuente) {
        selector.setFont(new Font(Font.SANS_SERIF, Font.BOLD, Math.max(14, tamanoFuente)));
        selector.setForeground(new Color(0x263A2B));
        selector.setBackground(new Color(0xFBFAF5));
        selector.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(0xAAB69B)),
                new EmptyBorder(3, 6, 3, 6)));
        selector.setFocusable(true);
        selector.setRenderer(new DefaultListCellRenderer() {
            @Override
            public Component getListCellRendererComponent(JList<?> lista, Object valor,
                    int indice, boolean seleccionado, boolean conFoco) {
                JLabel opcion = (JLabel) super.getListCellRendererComponent(
                        lista, valor, indice, seleccionado, conFoco);
                opcion.setFont(new Font(Font.SANS_SERIF, Font.BOLD, Math.max(14, tamanoFuente)));
                opcion.setOpaque(true);
                opcion.setBorder(new EmptyBorder(6, 9, 6, 9));
                opcion.setBackground(seleccionado ? new Color(0x3A5F40) : new Color(0xFBFAF5));
                opcion.setForeground(seleccionado ? new Color(0xFFF4D6) : new Color(0x263A2B));
                return opcion;
            }
        });
    }

    private JComponent crearPanelReto() {
        JPanel reto = new JPanel(new BorderLayout(12, 3)) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setPaint(new GradientPaint(0, 0, new Color(0x263A2B),
                        getWidth(), getHeight(), new Color(0x6B7F3E)));
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 16, 16);
                g2.dispose();
            }
        };
        reto.setOpaque(false);
        reto.setBorder(new EmptyBorder(8, 12, 8, 12));

        JLabel titulo = new JLabel("OBJETIVO");
        titulo.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 14));
        titulo.setForeground(new Color(0xF4A261));
        JLabel explicacion = new JLabel(
                "<html>Ubica N reinas, una por fila, sin que ninguna pareja comparta columna o diagonal.</html>");
        explicacion.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 15));
        explicacion.setForeground(Color.WHITE);
        JPanel consigna = new JPanel(new GridLayout(0, 1, 2, 2));
        consigna.setOpaque(false);
        consigna.add(titulo);
        consigna.add(explicacion);
        reto.add(consigna, BorderLayout.CENTER);

        barraProgreso.setStringPainted(true);
        barraProgreso.setForeground(new Color(0xB7E4C7));
        barraProgreso.setBackground(new Color(0xE2E8F0));
        barraProgreso.setBorderPainted(false);
        barraProgreso.setPreferredSize(new Dimension(200, 22));
        lblRetoProgreso.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 12));
        lblRetoProgreso.setForeground(Color.WHITE);
        JPanel avance = new JPanel(new BorderLayout(2, 3));
        avance.setOpaque(false);
        avance.setPreferredSize(new Dimension(220, 44));
        avance.add(lblRetoProgreso, BorderLayout.NORTH);
        avance.add(barraProgreso, BorderLayout.SOUTH);
        reto.add(avance, BorderLayout.EAST);
        return reto;
    }

    private JComponent crearPanelTexto(String contenido) {
        JEditorPane texto = new JEditorPane("text/html",
                FUENTES_CREDITOS.equals(contenido) ? crearHtmlCreditos()
                        : crearHtml(contenido));
        texto.setEditable(false);
        texto.setBackground(Color.WHITE);
        texto.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 15));
        texto.putClientProperty(JEditorPane.HONOR_DISPLAY_PROPERTIES, Boolean.TRUE);
        texto.setCaretPosition(0);
        if (FUENTES_CREDITOS.equals(contenido)) {
            texto.addHyperlinkListener(evento -> {
                if (evento.getEventType() == javax.swing.event.HyperlinkEvent.EventType.ENTERED) {
                    texto.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
                } else if (evento.getEventType() == javax.swing.event.HyperlinkEvent.EventType.EXITED) {
                    texto.setCursor(Cursor.getDefaultCursor());
                } else if (evento.getEventType() == javax.swing.event.HyperlinkEvent.EventType.ACTIVATED) {
                    abrirEnlaceFuente(texto, evento.getURL());
                }
            });
        }
        JScrollPane scroll = new JScrollPane(texto);
        scroll.setBorder(null);
        scroll.getVerticalScrollBar().setUnitIncrement(18);
        if (PSEUDOCODIGO.equals(contenido)) {
            JPanel pagina = new JPanel(new BorderLayout(0, 8));
            pagina.setBackground(new Color(0xF3F0E7));
            pagina.setBorder(new EmptyBorder(16, 18, 16, 18));
            pagina.add(scroll, BorderLayout.CENTER);
            JPanel practica = new JPanel(new BorderLayout(12, 0));
            practica.setBackground(new Color(0xEAF3F0));
            practica.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(new Color(0xC6D5CC)),
                    new EmptyBorder(10, 14, 10, 14)));
            JLabel pista = new JLabel("Sigue cada decisión en el tablero y en su lógica.");
            pista.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 14));
            pista.setForeground(AZUL_OSCURO);
            JButton abrirAnimacion = new JButton("Abrir ejemplo · N = 4");
            estilizarBoton(abrirAnimacion, new Color(0x173B35));
            abrirAnimacion.addActionListener(evento -> abrirAnimacion(4));
            JButton abrirCasos = new JButton("Ver ejemplos N=1–4");
            estilizarBoton(abrirCasos, new Color(0x6B7F3E));
            abrirCasos.addActionListener(evento -> tabs.setSelectedIndex(1));
            practica.add(pista, BorderLayout.CENTER);
            JPanel accesos = new JPanel(new FlowLayout(FlowLayout.RIGHT, 6, 0));
            accesos.setOpaque(false);
            accesos.add(abrirCasos);
            accesos.add(abrirAnimacion);
            practica.add(accesos, BorderLayout.EAST);
            pagina.add(practica, BorderLayout.SOUTH);
            return pagina;
        }
        return scroll;
    }

    private void abrirAnimacion(int n) {
        boolean mismoTablero = Integer.valueOf(n).equals(cmbN.getSelectedItem());
        tabs.setSelectedIndex(0);
        if (mismoTablero) {
            reiniciar();
        } else {
            cmbN.setSelectedItem(n);
        }
    }

    private void abrirEnlaceFuente(JEditorPane origen, java.net.URL url) {
        if (!Desktop.isDesktopSupported()
                || !Desktop.getDesktop().isSupported(Desktop.Action.BROWSE)) {
            JOptionPane.showMessageDialog(origen,
                    "Este equipo no tiene un navegador disponible para abrir el enlace.",
                    "No se pudo abrir la fuente", JOptionPane.WARNING_MESSAGE);
            return;
        }
        try {
            Desktop.getDesktop().browse(url.toURI());
        } catch (IOException | java.net.URISyntaxException
                 | UnsupportedOperationException | SecurityException error) {
            JOptionPane.showMessageDialog(origen,
                    "No se pudo abrir la fuente seleccionada.\n" + error.getMessage(),
                    "Error al abrir el enlace", JOptionPane.ERROR_MESSAGE);
        }
    }

    private String crearHtmlCreditos() {
        StringBuilder html = new StringBuilder("""
                <html><head><style>
                body { font-family: 'Segoe UI', sans-serif; font-size: 15px; color: #243247;
                       background: #F4F7FB; margin: 16px 20px; }
                h1 { font-size: 25px; color: #172554; margin: 4px 0 12px; }
                h2 { font-size: 17px; color: #173B35; margin: 0 0 10px; }
                p { margin: 7px 0 8px; line-height: 1.35; }
                a { color: #155E75; font-weight: bold; }
                li { margin: 6px 0; }
                </style></head><body>
                <h1>Créditos y fuentes</h1>
                """);

        agregarTarjetaCreditos(html, "Tecnología y desarrollo",
                "<ul><li><b>Lenguaje:</b> Java 17 (JDK 17).</li>"
                        + "<li><b>Interfaz y renderizado:</b> Java Swing / AWT.</li>"
                        + "<li><b>Entorno:</b> Visual Studio Code.</li></ul>");

        agregarTarjetaCreditos(html, "Asistencia de desarrollo",
                "<ul><li><b>Anthropic Claude (Codex / Claude 3.5 Sonnet):</b> asistencia en la lógica de "
                        + "animación paso a paso, la estructura del tablero y la integración de componentes.<br>"
                        + "</li><li><b>GitHub Copilot:</b> sugerencias de código y autocompletado durante el desarrollo.</li></ul>");

        agregarTarjetaCreditos(html, "Referencias técnicas",
                "<table width='100%' cellpadding='7' cellspacing='0'><tr><td width='28' bgcolor='#E8EFFA'><b>1</b></td><td>"
                        + "<p>Cormen, T. H., Leiserson, C. E., Rivest, R. L., &amp; Stein, C. (2009). "
                        + "<i>Introduction to algorithms</i> (3rd ed.). MIT Press.<br>"
                        + "<a href='https://mitpress.mit.edu/9780262033848/introduction-to-algorithms/'>"
                        + "Abrir la ficha editorial del libro ↗</a></p>"
                        + "</td></tr></table>"
                        + "<table width='100%' cellpadding='7' cellspacing='0'><tr><td width='28' bgcolor='#E8EFFA'><b>2</b></td><td>"
                        + "<p>Oracle. (s. f.). <i>Graphics2D (Java SE 17 &amp; JDK 17)</i>. "
                        + "Java Platform, Standard Edition 17 API Specification.<br>"
                        + "<a href='https://docs.oracle.com/en/java/javase/17/docs/api/java.desktop/java/awt/Graphics2D.html'>"
                        + "Abrir la referencia oficial de Graphics2D ↗</a></p>"
                        + "</td></tr></table>"
                        + "<table width='100%' cellpadding='7' cellspacing='0'><tr><td width='28' bgcolor='#E8EFFA'><b>3</b></td><td>"
                        + "<p>Oracle. (s. f.). <i>javax.swing (Java SE 17 &amp; JDK 17)</i>. "
                        + "Java Platform, Standard Edition 17 API Specification.<br>"
                        + "<a href='https://docs.oracle.com/en/java/javase/17/docs/api/java.desktop/javax/swing/package-summary.html'>"
                        + "Abrir la referencia oficial de Swing para Java 17 ↗</a></p>"
                        + "</td></tr></table>"
                        + "<table width='100%' cellpadding='7' cellspacing='0'><tr><td width='28' bgcolor='#E8EFFA'><b>4</b></td><td>"
                        + "<p>DigitalOcean. (s. f.). <i>N-Queens problem using backtracking in Java/C++</i>.<br>"
                        + "<a href='https://www.digitalocean.com/community/tutorials/n-queens-problem-java-c-plus-plus'>"
                        + "Abrir el tutorial de DigitalOcean ↗</a></p>"
                        + "</td></tr></table>"
                        + "<table width='100%' cellpadding='7' cellspacing='0'><tr><td width='28' bgcolor='#E8EFFA'><b>5</b></td><td>"
                        + "<p>GeeksforGeeks. (s. f.). <i>N-Queen problem | Backtracking-3</i>.<br>"
                        + "<a href='https://www.geeksforgeeks.org/dsa/n-queen-problem-backtracking-3/'>"
                        + "Abrir el artículo de GeeksforGeeks ↗</a></p>"
                        + "</td></tr></table>");

        agregarTarjetaCreditos(html, "Videos",
                "<table width='100%' cellpadding='7' cellspacing='0'><tr><td width='28' bgcolor='#EAF3F0'><b>1</b></td><td>"
                        + "<p>Tabares, B. [Brayan Tabares]. (s. f.). <i>Problema de las N-reinas | Backtracking en Java</i> [Video]. YouTube.<br>"
                        + "<a href='https://www.youtube.com/watch?v=jaIFNwtbDB0'>"
                        + "Ver el video citado ↗</a></p>"
                        + "</td></tr></table>"
                        + "<table width='100%' cellpadding='7' cellspacing='0'><tr><td width='28' bgcolor='#EAF3F0'><b>2</b></td><td>"
                        + "<p>XgamerCode. (s. f.). <i>Algoritmos “inteligentes” Backtracking | El problema de las N reinas</i> [Video]. YouTube.<br>"
                        + "<a href='https://www.youtube.com/watch?v=s7kBjMOMWg0'>"
                        + "Ver el video citado ↗</a></p>"
                        + "</td></tr></table>");

        return html.append("</body></html>").toString();
    }

    private void agregarTarjetaCreditos(StringBuilder html, String titulo, String contenido) {
        html.append("<table width='100%' cellpadding='14' cellspacing='0' bgcolor='#FFFFFF' border='1' bordercolor='#D8E0DA'>")
                .append("<tr><td><h2>").append(titulo).append("</h2>")
                .append(contenido).append("</td></tr></table><br>");
    }

    private JComponent crearPanelComplejidad() {
        JPanel pagina = new JPanel(new BorderLayout(10, 10));
        pagina.setBackground(new Color(0xF1F0E6));
        pagina.setBorder(new EmptyBorder(12, 14, 12, 14));

        JLabel titulo = new JLabel("Complejidad del algoritmo");
        titulo.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 22));
        titulo.setForeground(AZUL_OSCURO);
        JLabel bajada = new JLabel("Selecciona N para comparar la cota con los intentos de la animación.");
        bajada.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 14));
        bajada.setForeground(new Color(0x526078));
        JPanel titular = new JPanel(new GridLayout(0, 1, 3, 3));
        titular.setOpaque(false);
        titular.add(titulo);
        titular.add(bajada);

        sliderComplejidad = new JSlider(1, 8, 4);
        sliderComplejidad.setMajorTickSpacing(1);
        sliderComplejidad.setPaintTicks(true);
        sliderComplejidad.setPaintLabels(true);
        sliderComplejidad.setSnapToTicks(true);
        sliderComplejidad.setOpaque(false);
        lblNComplejidad.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 21));
        lblNComplejidad.setForeground(new Color(0x3A5F40));
        JPanel selectorPanel = new JPanel(new BorderLayout(10, 4));
        selectorPanel.setOpaque(false);
        selectorPanel.add(lblNComplejidad, BorderLayout.WEST);
        selectorPanel.add(sliderComplejidad, BorderLayout.CENTER);
        sliderComplejidad.setToolTipText("Selecciona un N de 1 a 8, disponible también en la animación.");

        JPanel tarjetas = new JPanel(new GridLayout(1, 2, 10, 0));
        tarjetas.setOpaque(false);
        tarjetas.add(crearTarjetaComplejidad("ESTADOS PARCIALES · COTA",
                lblEstadosCota, "Máximo de configuraciones parciales sin repetir columnas, incluida la raíz y las hojas.",
                new Color(0xF1E8D5), AZUL_OSCURO));
        tarjetas.add(crearTarjetaComplejidad("INTENTOS · COTA SIN PODA DIAGONAL",
            lblIntentosCota, "Límite conservador: hasta N candidatas por estado; la poda diagonal reduce los intentos reales.",
                new Color(0xEAF3F0), new Color(0x14532D)));

        lblActividadComplejidad.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 15));
        lblActividadComplejidad.setForeground(AZUL_OSCURO);
        lblActividadComplejidad.setEditable(false);
        lblActividadComplejidad.setFocusable(false);
        lblActividadComplejidad.setLineWrap(true);
        lblActividadComplejidad.setWrapStyleWord(true);
        lblActividadComplejidad.setOpaque(true);
        lblActividadComplejidad.setBackground(new Color(0xF4E7C5));
        lblActividadComplejidad.setBorder(new EmptyBorder(9, 11, 9, 11));
        JButton comparar = new JButton("Abrir esta búsqueda");
        comparar.setToolTipText("Abrir la animación principal con el mismo valor de N.");
        estilizarBoton(comparar, new Color(0x173B35));
        comparar.addActionListener(evento -> abrirAnimacion(selectorNComplejidad));
        JPanel lecturaReal = new JPanel(new BorderLayout(10, 0));
        lecturaReal.setOpaque(false);
        lecturaReal.add(lblActividadComplejidad, BorderLayout.CENTER);
        JPanel acciones = new JPanel(new FlowLayout(FlowLayout.RIGHT, 7, 0));
        acciones.setOpaque(false);
        configurarBadgeAhorro();
        acciones.add(lblAhorroPoda);
        acciones.add(comparar);
        lecturaReal.add(acciones, BorderLayout.EAST);
        JPanel panelSuperior = new JPanel(new GridBagLayout());
        panelSuperior.setBackground(Color.WHITE);
        panelSuperior.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(0xD8E0DA)),
                new EmptyBorder(13, 15, 13, 15)));
        GridBagConstraints superior = new GridBagConstraints();
        superior.gridx = 0;
        superior.weightx = 1;
        superior.fill = GridBagConstraints.HORIZONTAL;
        superior.anchor = GridBagConstraints.NORTH;
        superior.insets = new Insets(0, 0, 8, 0);
        superior.gridy = 0;
        JPanel encabezadoSelector = new JPanel(new BorderLayout(20, 8));
        encabezadoSelector.setOpaque(false);
        encabezadoSelector.add(titular, BorderLayout.WEST);
        encabezadoSelector.add(selectorPanel, BorderLayout.CENTER);
        panelSuperior.add(encabezadoSelector, superior);
        superior.gridy = 1;
        superior.insets = new Insets(0, 0, 8, 0);
        panelSuperior.add(tarjetas, superior);
        superior.gridy = 2;
        superior.insets = new Insets(0, 0, 0, 0);
        panelSuperior.add(lecturaReal, superior);

        sliderComplejidad.addChangeListener(e -> actualizarCotas(sliderComplejidad.getValue()));
        actualizarCotas(sliderComplejidad.getValue());

        graficoComplejidad = new PanelGraficoComplejidad();
        JSplitPane detalle = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT,
                crearPanelTexto(COMPLEJIDAD), graficoComplejidad);
        detalle.setContinuousLayout(true);
        detalle.setBorder(null);
        JSplitPane division = new JSplitPane(JSplitPane.VERTICAL_SPLIT, panelSuperior, detalle);
        division.setContinuousLayout(true);
        division.setBorder(null);
        panelSuperior.setMinimumSize(new Dimension(520, 185));
        fijarDivisorAlPrimerLayout(division, 0.32);
        fijarDivisorAlPrimerLayout(detalle, 0.58);
        pagina.add(division, BorderLayout.CENTER);
        return pagina;
    }

    private JPanel crearTarjetaComplejidad(String encabezado, JLabel valor,
                                            String detalle, Color fondo, Color color) {
        JPanel tarjeta = new JPanel();
        tarjeta.setLayout(new BoxLayout(tarjeta, BoxLayout.Y_AXIS));
        tarjeta.setBackground(fondo);
        tarjeta.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(0xD8E0DA)),
                new EmptyBorder(7, 11, 7, 11)));
        tarjeta.setPreferredSize(new Dimension(300, 100));
        tarjeta.setMinimumSize(new Dimension(130, 92));
        JLabel etiqueta = new JLabel(encabezado);
        etiqueta.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 13));
        etiqueta.setForeground(color);
        etiqueta.setAlignmentX(Component.LEFT_ALIGNMENT);
        valor.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 30));
        valor.setForeground(color);
        valor.setHorizontalAlignment(SwingConstants.CENTER);
        valor.setAlignmentX(Component.CENTER_ALIGNMENT);
        valor.setPreferredSize(new Dimension(280, 34));
        valor.setMinimumSize(new Dimension(100, 34));
        valor.setMaximumSize(new Dimension(Integer.MAX_VALUE, 36));
        JTextArea descripcion = new JTextArea(detalle, 2, 24);
        descripcion.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 12));
        descripcion.setForeground(new Color(0x526078));
        descripcion.setOpaque(false);
        descripcion.setEditable(false);
        descripcion.setFocusable(false);
        descripcion.setLineWrap(true);
        descripcion.setWrapStyleWord(true);
        descripcion.setMargin(new Insets(0, 0, 0, 0));
        descripcion.setAlignmentX(Component.LEFT_ALIGNMENT);
        descripcion.setPreferredSize(new Dimension(280, 30));
        descripcion.setMaximumSize(new Dimension(Integer.MAX_VALUE, 32));
        tarjeta.setToolTipText(detalle);
        valor.setToolTipText(detalle);
        tarjeta.add(etiqueta);
        tarjeta.add(Box.createVerticalStrut(3));
        tarjeta.add(valor);
        tarjeta.add(Box.createVerticalStrut(2));
        tarjeta.add(descripcion);
        return tarjeta;
    }

    private void configurarBadgeAhorro() {
        lblAhorroPoda.setOpaque(true);
        lblAhorroPoda.setBackground(new Color(0xEAF3F0));
        lblAhorroPoda.setForeground(new Color(0x14532D));
        lblAhorroPoda.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 13));
        lblAhorroPoda.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(0xB9D0C2)),
                new EmptyBorder(7, 9, 7, 9)));
        lblAhorroPoda.setToolTipText("Proporción de intentos observados respecto de una cota superior sin poda diagonal; no representa tiempo ni ahorro medido.");
    }

    private void actualizarCotas(int n) {
        selectorNComplejidad = n;
        BigInteger intentos = cotaIntentos(n);
        NumberFormat formato = NumberFormat.getIntegerInstance(Locale.forLanguageTag("es"));
        NumberFormat porcentaje = NumberFormat.getPercentInstance(Locale.forLanguageTag("es"));
        porcentaje.setMaximumFractionDigits(1);
        lblNComplejidad.setText("N = " + n);
        lblEstadosCota.setText(formato.format(intentos.divide(BigInteger.valueOf(n))));
        lblIntentosCota.setText(formato.format(intentos));
        if (ultimoEstadoPrincipal != null && ultimoEstadoPrincipal.n() == n) {
            double proporcion = ultimoEstadoPrincipal.intentos() / intentos.doubleValue();
            if (ultimoEstadoPrincipal.tipo() == Tipo.INICIO) {
                lblActividadComplejidad.setText("N=" + n + " · La animación está en el inicio. "
                        + "Cota superior: " + formato.format(intentos)
                        + " intentos; avanza para observar el recorrido.");
            } else {
                lblActividadComplejidad.setText("Recorrido N=" + n + " · "
                        + formato.format(ultimoEstadoPrincipal.intentos()) + " intentos observados / "
                        + formato.format(intentos) + " de cota (" + porcentaje.format(proporcion)
                        + ") · " + ultimoEstadoPrincipal.conflictos() + " conflictos · "
                        + ultimoEstadoPrincipal.retrocesos() + " retrocesos");
            }
            boolean finalizado = ultimoEstadoPrincipal.tipo() == Tipo.SOLUCION
                    || ultimoEstadoPrincipal.tipo() == Tipo.SIN_SOLUCION;
            if (finalizado) {
                lblAhorroPoda.setText(porcentaje.format(proporcion) + " de la cota");
            } else if (ultimoEstadoPrincipal.tipo() == Tipo.INICIO) {
                lblAhorroPoda.setText("Pendiente");
            } else {
                lblAhorroPoda.setText("En curso");
            }
        } else {
            lblActividadComplejidad.setText("N=" + n + " · Cota sin poda diagonal: "
                    + formato.format(intentos) + " intentos. Ejecuta la animación para comparar el recorrido real.");
            lblAhorroPoda.setText("—");
        }
        if (graficoComplejidad != null) graficoComplejidad.repaint();
    }

    private BigInteger cotaIntentos(int n) {
        BigInteger estados = BigInteger.ONE;
        BigInteger permutaciones = BigInteger.ONE;
        for (int k = 1; k <= n; k++) {
            permutaciones = permutaciones.multiply(BigInteger.valueOf(n - k + 1L));
            estados = estados.add(permutaciones);
        }
        return estados.multiply(BigInteger.valueOf(n));
    }

    @SuppressWarnings("serial")
    private class PanelGraficoComplejidad extends JPanel {
        PanelGraficoComplejidad() {
            setBackground(Color.WHITE);
            setPreferredSize(new Dimension(420, 300));
            setMinimumSize(new Dimension(350, 220));
            setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(new Color(0xD8E0DA)),
                    new EmptyBorder(8, 8, 8, 8)));
            setToolTipText("Selecciona N con un clic. La barra representa una cota superior de intentos; el punto muestra los intentos observados en la animación.");
            addMouseListener(new java.awt.event.MouseAdapter() {
                @Override
                public void mouseClicked(java.awt.event.MouseEvent evento) {
                    int izquierda = 48;
                    int derecha = getWidth() - 14;
                    int arriba = 58;
                    int abajo = getHeight() - 36;
                    if (evento.getX() < izquierda || evento.getX() > derecha
                            || evento.getY() < arriba || evento.getY() > abajo) return;
                    double espacioPorN = (double) (derecha - izquierda) / 8.0;
                    int seleccionado = (int) ((evento.getX() - izquierda) / espacioPorN) + 1;
                    sliderComplejidad.setValue(Math.max(1, Math.min(8, seleccionado)));
                }
            });
            addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
                @Override
                public void mouseMoved(java.awt.event.MouseEvent evento) {
                    int izquierda = 48;
                    int derecha = getWidth() - 14;
                    int arriba = 58;
                    int abajo = getHeight() - 36;
                    if (evento.getX() >= izquierda && evento.getX() <= derecha
                            && evento.getY() >= arriba && evento.getY() <= abajo) {
                        double espacioPorN = (double) (derecha - izquierda) / 8.0;
                        int n = (int) ((evento.getX() - izquierda) / espacioPorN) + 1;
                        n = Math.max(1, Math.min(8, n));
                        NumberFormat formato = NumberFormat.getIntegerInstance(Locale.forLanguageTag("es"));
                        String detalle = "N=" + n + " · cota: "
                                + formato.format(cotaIntentos(n)) + " intentos";
                        if (ultimoEstadoPrincipal != null && ultimoEstadoPrincipal.n() == n
                                && ultimoEstadoPrincipal.intentos() > 0) {
                            detalle += " · animación: " + formato.format(ultimoEstadoPrincipal.intentos());
                        }
                        setToolTipText(detalle + " · clic para seleccionar");
                    }
                }
            });
        }

        @Override
        protected void paintComponent(Graphics g0) {
            super.paintComponent(g0);
            Graphics2D g = (Graphics2D) g0.create();
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            int izquierda = 48;
            int derecha = getWidth() - 14;
            int arriba = 58;
            int abajo = getHeight() - 36;
            if (derecha <= izquierda || abajo <= arriba) {
                g.dispose();
                return;
            }

            g.setColor(AZUL_OSCURO);
            g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 15));
            g.drawString("INTENTOS · escala logarítmica (base 10)", 12, 22);
            g.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 12));
            g.setColor(new Color(0x6B7F3E));
            g.fillRoundRect(12, 29, 11, 11, 3, 3);
            g.setColor(new Color(0x526078));
            g.drawString("Cota superior", 29, 39);
            g.setColor(new Color(0x3A5F40));
            g.fillOval(142, 30, 10, 10);
            g.setColor(new Color(0x526078));
            g.drawString("Intentos reales", 158, 39);

            double maxLog = 6.0;
            for (int potencia = 0; potencia <= 6; potencia += 1) {
                int y = abajo - (int) Math.round((abajo - arriba) * potencia / maxLog);
                g.setColor(new Color(0xE2E7DC));
                g.drawLine(izquierda, y, derecha, y);
                g.setColor(new Color(0x6E7565));
                g.drawString(potencia == 0 ? "1" : "10^" + potencia, 3, y + 4);
            }

            int anchoGrafico = derecha - izquierda;
            double espacio = (double) anchoGrafico / 8.0;
            for (int n = 1; n <= 8; n++) {
                double logCota = Math.min(maxLog, Math.log10(Math.max(1.0, cotaIntentos(n).doubleValue())));
                int alto = (int) Math.round((abajo - arriba) * logCota / maxLog);
                int xCentro = izquierda + (int) Math.round((n - 0.5) * espacio);
                int anchoBarra = Math.max(4, (int) (espacio * 0.56));
                int x = xCentro - anchoBarra / 2;
                g.setColor(n == selectorNComplejidad ? new Color(0xD9A441) : new Color(0x6B7F3E));
                g.fillRoundRect(x, abajo - alto, anchoBarra, alto, 5, 5);
                if (n == selectorNComplejidad && ultimoEstadoPrincipal != null
                        && ultimoEstadoPrincipal.n() == n) {
                    double real = Math.max(1.0, ultimoEstadoPrincipal.intentos());
                    int yReal = abajo - (int) Math.round((abajo - arriba)
                            * Math.log10(real) / maxLog);
                    g.setColor(new Color(0x3A5F40));
                    g.fillOval(xCentro - 5, yReal - 5, 10, 10);
                    g.setColor(Color.WHITE);
                    g.setStroke(new BasicStroke(1.4f));
                    g.drawOval(xCentro - 5, yReal - 5, 10, 10);
                }
                g.setColor(new Color(0x526078));
                g.setFont(new Font(Font.SANS_SERIF, n == selectorNComplejidad
                        ? Font.BOLD : Font.PLAIN, 12));
                String etiqueta = Integer.toString(n);
                int anchoTexto = g.getFontMetrics().stringWidth(etiqueta);
                g.drawString(etiqueta, xCentro - anchoTexto / 2, abajo + 14);
            }
            g.setColor(new Color(0x526078));
            g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 12));
            String ejeX = "Tamaño del tablero (N)";
            g.drawString(ejeX, izquierda + (derecha - izquierda
                    - g.getFontMetrics().stringWidth(ejeX)) / 2, getHeight() - 7);
            g.dispose();
        }
    }

    private String crearHtml(String contenido) {
        if (COMPLEJIDAD.equals(contenido)) return crearHtmlComplejidad();
        StringBuilder html = new StringBuilder("""
                <html><head><style>
                body { font-family: 'Segoe UI', sans-serif; font-size: 17px; color: #243247;
                       background: #FFFFFF; margin: 17px 21px; }
                h1 { font-size: 25px; color: #172554; margin: 5px 0 15px;
                     padding: 0 0 9px; border-bottom: 3px solid #5B8067; }
                h2 { font-size: 19px; color: #173B35; margin: 16px 0 8px;
                     padding: 0 0 5px; border-bottom: 1px solid #D8E0DA; }
                p { margin: 10px 0 13px; line-height: 1.4; }
                td { padding: 13px 14px; line-height: 1.4; }
                pre { font-family: Consolas, monospace; font-size: 15px; color: #E2E8F0;
                      background: #172033; margin: 10px 0 16px; padding: 15px 17px;
                      border-left: 4px solid #5B8067; }
                </style></head><body>
                """);
        if (PSEUDOCODIGO.equals(contenido)) {
            String[] lineas = contenido.strip().split("\\R");
            String objetivo = lineas[0].trim();
            int procedimiento = -1, conexion = -1;
            for (int i = 1; i < lineas.length; i++) {
                String linea = lineas[i].trim();
                if (linea.equals("PROCEDIMIENTO resolver(fila)")) procedimiento = i;
                else if (linea.equals("CONEXIÓN CON LA ANIMACIÓN")) conexion = i;
            }
            html.append("<h1>").append(escaparHtml(objetivo)).append("</h1>")
                    .append("<p>La búsqueda construye la solución fila por fila. "
                            + "Las coordenadas se numeran desde cero; ")
                    .append("<b>reinas[fila]</b> guarda la columna elegida y −1 representa "
                            + "una fila vacía. Como cada fila recibe una sola reina, "
                            + "solo es necesario comprobar columnas y diagonales.</p>")
                    .append("<table width='100%' cellpadding='5' cellspacing='5' border='0'><tr>")
                    .append("<td width='50%' bgcolor='#F1F0E6' valign='top'><b>REPRESENTACIÓN · N = 4</b><br>")
                    .append("<b>reinas[] = [1, 3, 0, 2]</b> se lee así: fila 0 → columna 1, "
                            + "fila 1 → columna 3, fila 2 → columna 0 y fila 3 → columna 2. "
                            + "En los arreglos auxiliares, -1 significa libre; otro valor "
                            + "indica la fila que ocupa esa columna o diagonal.</td>")
                    .append("<td width='50%' bgcolor='#EAF3F0' valign='top'><b>ÍNDICES DE DIAGONAL · N = 4</b><br>")
                    .append("Las diagonales se ubican con fila − columna + N − 1 y fila + columna. "
                            + "Para (1, 3): 1 − 3 + 4 − 1 = 1 y 1 + 3 = 4. El desplazamiento "
                            + "N − 1 mantiene los índices dentro del arreglo, sin valores negativos.</td>")
                    .append("</tr></table>")
                    .append("<h2>Procedimiento de búsqueda</h2><pre>");
            int inicioCodigo = procedimiento < 0 ? 1 : procedimiento;
            int finCodigo = conexion < 0 ? lineas.length : conexion;
            for (int i = inicioCodigo; i < finCodigo; i++) {
                html.append(escaparHtml(lineas[i])).append('\n');
            }
            html.append("</pre><h2>Por qué funciona</h2>")
                    .append("<p>Una llamada solo avanza cuando la candidata no comparte columna ni "
                            + "diagonal con las reinas ya colocadas. Si las filas posteriores no "
                            + "pueden completarse, se deshacen exactamente las marcas de la última "
                            + "decisión y se intenta otra columna. Así se exploran las alternativas "
                            + "sin descartar una solución válida.</p>");
            if (conexion >= 0) {
                html.append("<h2>El tablero y el algoritmo, paso a paso</h2>")
                        .append("<table width='100%' cellpadding='5' cellspacing='3' border='0'>");
                for (int i = conexion + 1; i < lineas.length; i++) {
                    String texto = lineas[i].trim();
                    if (texto.isEmpty()) continue;
                    int separador = texto.indexOf(" · ");
                    if (separador > 0) {
                        html.append("<tr><td width='125' bgcolor='#EAF3F0' valign='top'><b>")
                                .append(escaparHtml(texto.substring(0, separador)))
                                .append("</b></td><td bgcolor='#F4F7FB'>")
                                .append(escaparHtml(texto.substring(separador + 3)))
                                .append("</td></tr>");
                    }
                }
                html.append("</table>");
            }
            return html.append("</body></html>").toString();
        }

        StringBuilder parrafo = new StringBuilder();
        StringBuilder viñeta = new StringBuilder();
        boolean tituloPrincipal = true;
        boolean listaAbierta = false;
        for (String linea : contenido.strip().split("\\R")) {
            String texto = linea.trim();
            if (texto.isEmpty()) {
                cerrarParrafo(html, parrafo);
                listaAbierta = cerrarLista(html, viñeta, listaAbierta);
                continue;
            }
            if (texto.equals(texto.toUpperCase(Locale.ROOT)) && texto.length() > 2) {
                cerrarParrafo(html, parrafo);
                listaAbierta = cerrarLista(html, viñeta, listaAbierta);
                html.append(tituloPrincipal ? "<h1>" : "<h2>")
                        .append(escaparHtml(texto))
                        .append(tituloPrincipal ? "</h1>" : "</h2>");
                tituloPrincipal = false;
            } else if (texto.startsWith("•")) {
                cerrarParrafo(html, parrafo);
                if (!listaAbierta) {
                    html.append("<table width='100%' cellpadding='1' cellspacing='0' border='0'>");
                    listaAbierta = true;
                }
                cerrarVinyeta(html, viñeta);
                viñeta.append(escaparHtml(texto.substring(1).trim()));
            } else if (listaAbierta && (Character.isWhitespace(linea.charAt(0)) || viñeta.length() > 0)) {
                if (viñeta.length() > 0) viñeta.append(' ');
                viñeta.append(escaparHtml(texto));
            } else {
                listaAbierta = cerrarLista(html, viñeta, listaAbierta);
                if (parrafo.length() > 0) parrafo.append(' ');
                parrafo.append(escaparHtml(texto));
            }
        }
        cerrarParrafo(html, parrafo);
        cerrarLista(html, viñeta, listaAbierta);
        return html.append("</body></html>").toString();
    }

    private String crearHtmlComplejidad() {
        return """
                <html><head><style>
                body { font-family: 'Segoe UI', sans-serif; font-size: 16px; color: #243247;
                       background: #FFFFFF; margin: 16px 19px; }
                h1 { font-size: 24px; color: #172554; margin: 4px 0 12px;
                     padding: 0 0 8px; border-bottom: 3px solid #769656; }
                h2 { font-size: 18px; color: #173B35; margin: 16px 0 8px;
                     padding: 0 0 5px; border-bottom: 1px solid #D8E0DA; }
                p { margin: 9px 0 12px; line-height: 1.4; }
                td { padding: 12px 13px; line-height: 1.35; }
                </style></head><body>
                <h1>Big O · cómo crece la búsqueda</h1>
                <p><b>N</b> es el número de filas y columnas, y también el número de reinas que se deben colocar. Big O describe cómo escala el trabajo al aumentar N; no predice segundos ni compara la velocidad de dos equipos.</p>
                <p>Esta solución procesa una fila a la vez. Como las filas ya son distintas, comprueba únicamente columnas y diagonales. Las cifras siguientes separan el costo del algoritmo del trabajo adicional de guardar la animación.</p>

                <h2>1 · Tiempo: del árbol a las comprobaciones</h2>
                <table width='100%' cellpadding='5' cellspacing='5' border='0'>
                  <tr>
                    <td width='50%' bgcolor='#E8EFFA' valign='top'><b>ESTADOS PARCIALES · O(N!)</b><br>
                      En el nivel k ya hay k filas ocupadas. Como no se repite columna, hay como máximo P(N,k) = N!/(N−k)! configuraciones. Al sumar los niveles, Σ P(N,k) &lt; e·N!, así que el número de estados es O(N!). Las diagonales descartan muchas de esas configuraciones antes de expandirlas.</td>
                    <td width='50%' bgcolor='#EAF3F0' valign='top'><b>UNA COMPROBACIÓN · O(1)</b><br>
                      columnaPor, diagonalPor y antidiagonalPor indican si la columna y las dos diagonales están ocupadas. Tres accesos directos bastan; no se recorre la lista de reinas anteriores.</td>
                  </tr>
                </table>
                <p>Desde cada estado se pueden examinar hasta N columnas. Multiplicar O(N!) estados por hasta N candidatas da la <b>cota superior conservadora O(N·N!)</b> para las pruebas. No es una cuenta exacta del recorrido: la poda por diagonales evita explorar ramas incompatibles.</p>
                <p><b>Alcance de esta búsqueda:</b> el programa se detiene al encontrar la primera solución. No enumera todas las soluciones ni busca una solución “mejor”. El recorrido concreto depende del orden de las columnas; por eso sus intentos pueden ser muchos menos que la cota.</p>

                <h2>2 · Ejemplo: qué significa la cota para N = 4</h2>
                <table width='100%' cellpadding='6' cellspacing='4' border='0'>
                  <tr>
                    <td width='33%' bgcolor='#F1F0E6' valign='top'><b>65 configuraciones</b><br>
                      1 tablero vacío + 4 configuraciones con una reina + 12 con dos + 24 con tres + 24 completas. Es el total si se consideran todas las permutaciones de columnas, antes de podar por diagonales.</td>
                    <td width='33%' bgcolor='#E8EFFA' valign='top'><b>260 pruebas como cota</b><br>
                      65 × 4 es un límite sencillo: asigna hasta cuatro candidatas a cada configuración. Sobrecuenta estados que no necesitan probar otra columna; no predice los intentos exactos.</td>
                    <td width='33%' bgcolor='#EAF3F0' valign='top'><b>Recorrido observado</b><br>
                      La animación registra las candidatas del orden de búsqueda elegido y termina en la primera solución. Son comprobaciones, no milisegundos ni “eventos ahorrados”.</td>
                  </tr>
                </table>

                <h2>3 · Escenarios: qué se puede afirmar</h2>
                <table width='100%' cellpadding='6' cellspacing='5' border='0'>
                  <tr>
                    <td width='33%' bgcolor='#FCE8E6' valign='top'><b>COTA SUPERIOR</b><br>
                      O(N·N!) limita las pruebas posibles con esta representación. El árbol real suele ser menor gracias a la poda y a que la búsqueda se detiene en la primera solución.</td>
                    <td width='33%' bgcolor='#EAF3F0' valign='top'><b>RUTA FAVORABLE</b><br>
                      Una ruta sin retrocesos requiere al menos visitar N filas. Si se examina un número constante de candidatas por fila, cuesta O(N); si se prueban hasta N en cada fila, puede llegar a O(N²).</td>
                    <td width='33%' bgcolor='#FFF4D6' valign='top'><b>PROMEDIO</b><br>
                      No hay un promedio definido sin especificar una distribución de tamaños y ejecuciones. La cota superior no debe presentarse como promedio.</td>
                  </tr>
                </table>
                <p>Las diagonales se indexan con <b>fila − columna + N − 1</b> y <b>fila + columna</b>. Cada índice queda entre 0 y 2N−2, de modo que cada arreglo necesita 2N−1 posiciones. El desplazamiento +N−1 evita índices negativos.</p>

                <h2>4 · Memoria: búsqueda y registro visual</h2>
                <table width='100%' cellpadding='5' cellspacing='4' border='0'>
                  <tr>
                    <td width='50%' bgcolor='#F1F0E6' valign='top'><b>ALGORITMO · O(N)</b><br>
                      Los arreglos guardan N columnas y 2N−1 posiciones para cada diagonal. La pila recursiva alcanza N+1 llamadas como máximo. El algoritmo modifica y reutiliza estos arreglos; no almacena el árbol de búsqueda.</td>
                    <td width='50%' bgcolor='#EAF3F0' valign='top'><b>ANIMACIÓN · O(S·N)</b><br>
                      Para reproducir y retroceder, la interfaz guarda S instantáneas. Cada una copia el tablero y las identidades por fila; además se guardan los mensajes. Esta memoria adicional pertenece al historial visual.</td>
                  </tr>
                </table>

                <h2>5 · Lee el gráfico y los contadores</h2>
                <p>El gráfico usa escala logarítmica base 10 para que N pequeños y grandes quepan en el mismo eje. La barra es la cota superior de intentos; el punto verde, los intentos observados en la ejecución del tamaño seleccionado. El porcentaje junto al botón expresa <b>qué proporción de la cota representa ese recorrido</b>; no es un ahorro medido.</p>
                <p><b>Intentos</b> cuenta cada candidata examinada, segura o atacada. <b>Conflictos</b> es el subconjunto descartado. <b>Retrocesos</b> cuenta decisiones colocadas que se retiran cuando una llamada devuelve false. Los contadores miden cosas distintas y no se suman para estimar tiempo.</p>
                </body></html>
                """;
    }

    private boolean cerrarLista(StringBuilder html, StringBuilder viñeta, boolean listaAbierta) {
        cerrarVinyeta(html, viñeta);
        if (listaAbierta) html.append("</table><br>");
        return false;
    }

    private void cerrarVinyeta(StringBuilder html, StringBuilder viñeta) {
        if (viñeta.length() == 0) return;
        html.append("<tr><td width='20' valign='top'><font color='#0F766E'><b>•</b></font></td><td>")
                .append(viñeta).append("</td></tr>");
        viñeta.setLength(0);
    }

    private void cerrarParrafo(StringBuilder html, StringBuilder parrafo) {
        if (parrafo.length() == 0) return;
        html.append("<p>").append(parrafo).append("</p>");
        parrafo.setLength(0);
    }

    private String escaparHtml(String texto) {
        return texto.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
    }

    private JComponent crearPanelCasos() {
        miniSimulacion = new MiniSimulacion();
        miniSimulacion.setPaleta(paletaSeleccionada());
        miniSimulacion.setHeatmapActivo(btnRangos.isSelected());
        miniSimulacion.setRitmo(temporizador.getDelay());
        JPanel pagina = new JPanel(new BorderLayout(12, 12));
        pagina.setBackground(new Color(0xF1F0E6));
        pagina.setBorder(new EmptyBorder(14, 16, 14, 16));

        JLabel titulo = new JLabel("Casos y demostraciones");
        titulo.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 24));
        titulo.setForeground(AZUL_OSCURO);
        JLabel introduccion = new JLabel(
                "Compara el caso base, dos tableros sin solución y una búsqueda que sí encuentra salida.");
        introduccion.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 15));
        introduccion.setForeground(new Color(0x526078));
        JPanel encabezado = new JPanel(new GridLayout(0, 1, 0, 3));
        encabezado.setOpaque(false);
        encabezado.add(titulo);
        encabezado.add(introduccion);
        pagina.add(encabezado, BorderLayout.NORTH);

        JPanel selector = new JPanel();
        selector.setLayout(new BoxLayout(selector, BoxLayout.Y_AXIS));
        selector.setBackground(Color.WHITE);
        selector.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(0xD8E0DA)),
                new EmptyBorder(12, 12, 12, 12)));
        JLabel selectorTitulo = new JLabel("ELIGE UN EJEMPLO");
        selectorTitulo.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 14));
        selectorTitulo.setForeground(new Color(0x173B35));
        selectorTitulo.setAlignmentX(Component.LEFT_ALIGNMENT);
        JPanel opciones = new JPanel(new GridLayout(4, 1, 0, 7));
        opciones.setOpaque(false);
        agregarSelectorCaso(opciones, 1, "N = 1   ·   Caso base");
        agregarSelectorCaso(opciones, 2, "N = 2   ·   Sin solución");
        agregarSelectorCaso(opciones, 3, "N = 3   ·   Sin solución");
        agregarSelectorCaso(opciones, 4, "N = 4   ·   Retroceso y solución");
        opciones.setAlignmentX(Component.LEFT_ALIGNMENT);
        opciones.setMaximumSize(new Dimension(Integer.MAX_VALUE, 4 * 42 + 3 * 7));
        selector.add(selectorTitulo);
        selector.add(Box.createVerticalStrut(9));
        selector.add(opciones);
        selector.add(Box.createVerticalStrut(12));

        resumenCaso.setEditable(false);
        resumenCaso.setBackground(new Color(0xFBFAF5));
        resumenCaso.putClientProperty(JEditorPane.HONOR_DISPLAY_PROPERTIES, Boolean.TRUE);
        resumenCaso.setBorder(new EmptyBorder(14, 14, 14, 14));
        resumenCaso.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 16));
        JScrollPane resumenDesplazable = new JScrollPane(resumenCaso);
        resumenDesplazable.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(new Color(0xD8E0DA)),
                "IDEA CLAVE"));
        resumenDesplazable.setPreferredSize(new Dimension(300, 290));
        resumenDesplazable.setMinimumSize(new Dimension(200, 170));
        resumenDesplazable.setMaximumSize(new Dimension(Integer.MAX_VALUE, Integer.MAX_VALUE));
        resumenDesplazable.setAlignmentX(Component.LEFT_ALIGNMENT);
        selector.add(resumenDesplazable);

        JPanel simulacion = new JPanel(new BorderLayout());
        simulacion.setOpaque(false);
        simulacion.add(miniSimulacion, BorderLayout.CENTER);
        JSplitPane division = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, selector, simulacion);
        division.setContinuousLayout(true);
        division.setBorder(null);
        division.setDividerSize(9);
        division.setMinimumSize(new Dimension(650, 350));
        selector.setMinimumSize(new Dimension(245, 350));
        miniSimulacion.setMinimumSize(new Dimension(450, 350));
        pagina.add(division, BorderLayout.CENTER);
        fijarDivisorAlPrimerLayout(division, 0.27);
        botonesCasos[3].doClick();
        return pagina;
    }

    private void agregarSelectorCaso(JPanel panel, int n, String texto) {
        JButton selector = new JButton(texto);
        botonesCasos[n - 1] = selector;
        selector.setHorizontalAlignment(SwingConstants.LEFT);
        selector.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 14));
        selector.setForeground(n == 1 || n == 4
                ? new Color(0x14532D) : new Color(0x92400E));
        selector.setBackground(n == 1 || n == 4
                ? new Color(0xEAF3F0) : new Color(0xFFF4D6));
        selector.setFocusPainted(false);
        selector.setOpaque(true);
        selector.setPreferredSize(new Dimension(280, 46));
        selector.setMinimumSize(new Dimension(220, 42));
        selector.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(0xD8E0DA)),
                new EmptyBorder(7, 9, 7, 9)));
        selector.setToolTipText("Iniciar una simulación independiente de N=" + n);
        selector.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        selector.setRolloverEnabled(true);
        Color fondoNormal = n == 1 || n == 4
            ? new Color(0xEAF3F0) : new Color(0xFFF4D6);
        Color tintaNormal = n == 1 || n == 4
                ? new Color(0x14532D) : new Color(0x92400E);
        selector.addActionListener(e -> {
            casoSeleccionado = n - 1;
            for (int i = 0; i < botonesCasos.length; i++) {
                boolean activo = i == casoSeleccionado;
                botonesCasos[i].setBackground(activo ? new Color(0x3A5F40)
                        : i == 0 || i == 3 ? new Color(0xEAF3F0) : new Color(0xFFF4D6));
                botonesCasos[i].setForeground(activo ? new Color(0xFFF4D6)
                        : i == 0 || i == 3 ? new Color(0x14532D) : new Color(0x92400E));
                botonesCasos[i].setBorder(BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(activo
                                ? new Color(0xD9A441) : new Color(0xD8E0DA), activo ? 2 : 1),
                        new EmptyBorder(7, 9, 7, 9)));
            }
            resumenCaso.setText(descripcionCaso(n));
            resumenCaso.setCaretPosition(0);
            miniSimulacion.iniciar(n);
        });
        selector.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseEntered(java.awt.event.MouseEvent evento) {
                if (casoSeleccionado != n - 1) selector.setBackground(n == 1 || n == 4
                        ? new Color(0xDDEADF) : new Color(0xF7E8BB));
            }

            @Override
            public void mouseExited(java.awt.event.MouseEvent evento) {
                boolean activo = casoSeleccionado == n - 1;
                selector.setBackground(activo ? new Color(0x3A5F40) : fondoNormal);
                selector.setForeground(activo ? new Color(0xFFF4D6) : tintaNormal);
            }
        });
        panel.add(selector);
    }

    private String descripcionCaso(int n) {
        return switch (n) {
            case 1 -> {
                yield htmlTarjetaCaso(n, "La condición de parada",
                        "En el tablero 1×1 solo existe la casilla (0, 0). La primera reina no tiene piezas anteriores con las que entrar en conflicto, así que la posición es segura.",
                        "resolver(0) prueba la columna 0 y la coloca. La llamada siguiente es resolver(1): como 1 = N, alcanza el caso base y devuelve true. La respuesta vuelve por la recursión sin probar más columnas.",
                        "La solución es [0]: la única fila, índice 0, usa la columna 0. Se comprueba una candidata, no hay conflictos ni retrocesos. Observa que el caso base se comprueba al entrar en resolver, después de colocar la última reina.");
            }
            case 2 -> {
                yield htmlTarjetaCaso(n, "Un árbol que termina sin solución",
                        "Si la reina de la fila 0 ocupa la columna 0, en la fila 1 la columna 0 repite columna y la columna 1 comparte diagonal. Las dos candidatas quedan descartadas.",
                        "La fila 1 devuelve false. El algoritmo retira la reina de (0, 0), libera columna y diagonales y prueba (0, 1). La reflexión del tablero produce el mismo bloqueo, pero el programa explora esa segunda rama explícitamente.",
                        "resolver(0) devuelve false después de agotar las dos columnas iniciales. Es un resultado correcto, no un fallo: para N=2 no existe una disposición válida. El caso muestra que el retroceso restaura el estado antes de explorar otra rama.");
            }
            case 3 -> {
                yield htmlTarjetaCaso(n, "Poda sin perder alternativas",
                        "En un tablero 3×3 tampoco existe solución. Con una reina en (0, 0), la única candidata segura de la fila 1 es (1, 2). Al colocarla, las tres casillas de la fila 2 quedan atacadas.",
                        "Cuando una fila no tiene ninguna columna segura, la llamada devuelve false sin crear llamadas más profundas para esa rama. Se retira la reina anterior y se prueban las columnas que todavía no se habían explorado.",
                        "Tras revisar todas las ramas posibles, resolver(0) devuelve false. La poda acorta ramas imposibles, pero no omite soluciones: solo descarta casillas que violan una regla. N=2 y N=3 son los únicos tamaños positivos sin solución.");
            }
            case 4 -> {
                yield htmlTarjetaCaso(n, "Retroceder para encontrar salida",
                        "La búsqueda recorre las columnas de izquierda a derecha. Al comenzar con (0, 0), la reina de (1, 2) deja la fila 2 sin posiciones seguras. El tablero vuelve al estado anterior para probar otra opción.",
                        "Al elegir la columna 1 en la fila 0, el recorrido encuentra [1, 3, 0, 2]: fila 0→columna 1, fila 1→3, fila 2→0 y fila 3→2. Cada nueva reina se comprueba contra las anteriores antes de avanzar.",
                        "resolver(4) alcanza el caso base y devuelve true. La primera solución aparece porque las columnas se prueban en orden; no significa que sea la única. Para N=4 existen dos disposiciones, y esta búsqueda se detiene en la primera.");
            }
            default -> throw new IllegalArgumentException("Caso de demostración no admitido: " + n);
        };
    }

    private String htmlTarjetaCaso(int n, String titulo, String mecanismo,
                                   String decision, String resultado) {
        String color = n == 1 || n == 4 ? "#14532D" : "#92400E";
        return "<html><head><style>body{font-family:'Segoe UI',sans-serif;font-size:16px;color:#243247;margin:10px}"
                + "p{line-height:1.4}td{line-height:1.4}</style></head><body>"
                + "<h2 style='font-size:23px;color:" + color + ";margin:4px 0 10px'>N = " + n + " · "
                + escaparHtml(titulo) + "</h2>"
                + "<p style='color:#526078;margin:0 0 14px'>Cada fila recibe como máximo una reina. "
                + "<b>reinas[fila]</b> guarda su columna; −1 indica que esa fila está vacía. "
                + "Las coordenadas de este ejemplo comienzan en cero.</p>"
                + "<table width='100%' cellpadding='14' cellspacing='0' border='0'>"
                + "<tr><td bgcolor='#F1F0E6'><b style='color:#526944'>SITUACIÓN</b><br><br>"
                + escaparHtml(mecanismo) + "</td></tr>"
                + "<tr><td height='8'></td></tr>"
                + "<tr><td bgcolor='#E8EFFA'><b style='color:#172554'>TRAZA DEL ALGORITMO</b><br><br>"
                + escaparHtml(decision) + "</td></tr>"
                + "<tr><td height='8'></td></tr>"
                + "<tr><td bgcolor='#EAF3F0'><b style='color:#14532D'>RESULTADO · QUÉ OBSERVAR</b><br><br>"
                + escaparHtml(resultado) + "</td></tr>"
                + "</table></body></html>";
    }

    private void estilizarBoton(JButton boton, Color color) {
        Color hover = color.brighter();
        boton.setBackground(color);
        boton.setForeground(Color.WHITE);
        boton.setFocusPainted(false);
        boton.setContentAreaFilled(true);
        boton.setOpaque(true);
        boton.setRolloverEnabled(true);
        boton.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 14));
        boton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        boton.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(color.darker()),
                new EmptyBorder(7, 11, 7, 11)));
        boton.setToolTipText(boton.getToolTipText() == null
                ? boton.getText() : boton.getToolTipText());
        boton.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseEntered(java.awt.event.MouseEvent evento) {
                if (boton.isEnabled()) boton.setBackground(hover);
            }

            @Override
            public void mouseExited(java.awt.event.MouseEvent evento) {
                boton.setBackground(color);
            }
        });
    }

    private JLabel itemLeyenda(Color fondo, Color texto, String s) {
        JLabel l = new JLabel(s);
        l.setOpaque(true);
        l.setBackground(fondo);
        l.setForeground(texto);
        l.setBorder(new EmptyBorder(4, 8, 4, 8));
        return l;
    }

    private JComponent crearPanelDuelo() {
        dueloReinas = new DueloReinas();
        return dueloReinas;
    }

    private class DueloReinas extends JPanel {
        private final int[][] piezas = new int[8][8];
        private final List<EstadoDuelo> historial = new ArrayList<>();
        private final JLabel estado = new JLabel("", SwingConstants.CENTER);
        private final DueloTablero tableroDuelo = new DueloTablero();
        private final JButton btnDeshacer = new JButton("↶ Deshacer");
        private final JButton btnNuevo = new JButton("Nueva partida");
        private int turno = 1;
        private int ganador;
        private int filaSeleccionada = -1;
        private int colSeleccionada = -1;
        private String mensaje;

        DueloReinas() {
            setLayout(new BorderLayout(10, 10));
            setBackground(new Color(0xF1F0E6));
            setBorder(new EmptyBorder(18, 22, 18, 22));

            JLabel titulo = new JLabel("Duelo de reinas · dos jugadores");
            titulo.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 24));
            titulo.setForeground(AZUL_OSCURO);
            JLabel reglas = new JLabel(
                    "Cada lado empieza con 8 reinas. Muévelas como una reina de ajedrez; gana quien capture todas las rivales.");
            reglas.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 14));
            reglas.setForeground(new Color(0x526078));
            JPanel encabezado = new JPanel(new GridLayout(0, 1, 4, 4));
            encabezado.setOpaque(false);
            encabezado.add(titulo);
            encabezado.add(reglas);
            estado.setOpaque(true);
            estado.setBackground(new Color(0xEAF3F0));
            estado.setForeground(AZUL_OSCURO);
            estado.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 15));
            estado.setBorder(new EmptyBorder(9, 12, 9, 12));
            JPanel centro = new JPanel(new BorderLayout(8, 8));
            centro.setOpaque(false);
            centro.add(encabezado, BorderLayout.NORTH);
            tableroDuelo.setPreferredSize(new Dimension(560, 560));
            centro.add(tableroDuelo, BorderLayout.CENTER);
            centro.add(estado, BorderLayout.SOUTH);
            add(centro, BorderLayout.CENTER);

            estilizarBoton(btnDeshacer, new Color(0x625D50));
            estilizarBoton(btnNuevo, new Color(0x173B35));
            btnDeshacer.setEnabled(false);
            btnDeshacer.addActionListener(e -> deshacer());
            btnNuevo.addActionListener(e -> nuevaPartida());
            JPanel controles = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 2));
            controles.setOpaque(false);
            controles.add(btnNuevo);
            controles.add(btnDeshacer);
            add(controles, BorderLayout.SOUTH);
            nuevaPartida();
        }

        void setPaleta(PaletaTablero paleta) {
            tableroDuelo.setPaleta(paleta);
        }

        private void nuevaPartida() {
            tableroDuelo.detenerAnimacion();
            for (int col = 0; col < 8; col++) {
                piezas[0][col] = -1;
                piezas[7][col] = 1;
            }
            for (int fila = 1; fila < 7; fila++) Arrays.fill(piezas[fila], 0);
            turno = 1;
            ganador = 0;
            filaSeleccionada = -1;
            colSeleccionada = -1;
            mensaje = "Comienza Blancas. Selecciona una reina y después su destino.";
            historial.clear();
            btnDeshacer.setEnabled(false);
            actualizarEstado();
            tableroDuelo.repaint();
        }

        private void deshacer() {
            if (historial.isEmpty()) return;
            tableroDuelo.detenerAnimacion();
            EstadoDuelo anterior = historial.remove(historial.size() - 1);
            for (int fila = 0; fila < 8; fila++) {
                piezas[fila] = anterior.tablero()[fila].clone();
            }
            turno = anterior.turno();
            ganador = anterior.ganador();
            mensaje = anterior.mensaje();
            filaSeleccionada = -1;
            colSeleccionada = -1;
            btnDeshacer.setEnabled(!historial.isEmpty());
            actualizarEstado();
            tableroDuelo.repaint();
        }

        private void clicEnCasilla(int fila, int col) {
            if (fila < 0 || fila >= 8 || col < 0 || col >= 8
                    || ganador != 0 || tableroDuelo.animacionActiva()) return;
            if (filaSeleccionada >= 0 && esMovimientoLegal(
                    filaSeleccionada, colSeleccionada, fila, col, turno)) {
                mover(fila, col);
                return;
            }
            if (piezas[fila][col] == turno) {
                filaSeleccionada = fila;
                colSeleccionada = col;
                mensaje = (turno == 1 ? "Blancas" : "Negras")
                        + " · elige una casilla marcada para mover o capturar.";
            } else {
                filaSeleccionada = -1;
                colSeleccionada = -1;
                mensaje = "Selecciona una reina de " + (turno == 1 ? "Blancas." : "Negras.");
            }
            actualizarEstado();
            tableroDuelo.repaint();
        }

        private void mover(int filaDestino, int colDestino) {
            int filaOrigen = filaSeleccionada;
            int colOrigen = colSeleccionada;
            int jugador = turno;
            int capturada = piezas[filaDestino][colDestino] == -jugador ? 1 : 0;
            historial.add(new EstadoDuelo(clonarTablero(piezas), turno, ganador, mensaje));
            piezas[filaDestino][colDestino] = jugador;
            piezas[filaOrigen][colOrigen] = 0;
            filaSeleccionada = -1;
            colSeleccionada = -1;
            turno = -turno;

            if (contarPiezas(-jugador) == 0) {
                ganador = jugador;
                mensaje = (jugador == 1 ? "¡Ganan Blancas!" : "¡Ganan Negras!")
                        + " Capturaron todas las reinas rivales.";
            } else if (!hayMovimientoLegal(turno)) {
                ganador = 2;
                mensaje = "Empate: " + (turno == 1 ? "Blancas" : "Negras")
                        + " no tiene movimientos legales.";
            } else {
                mensaje = (jugador == 1 ? "Blancas" : "Negras")
                        + (capturada == 1 ? " capturó una reina. " : " movió una reina. ")
                        + "Turno de " + (turno == 1 ? "Blancas." : "Negras.");
            }
            btnDeshacer.setEnabled(true);
            tableroDuelo.animarMovimiento(filaOrigen, colOrigen, filaDestino, colDestino);
            actualizarEstado();
        }

        private int contarPiezas(int jugador) {
            int cantidad = 0;
            for (int[] fila : piezas) {
                for (int pieza : fila) if (pieza == jugador) cantidad++;
            }
            return cantidad;
        }

        private boolean hayMovimientoLegal(int jugador) {
            for (int fila = 0; fila < 8; fila++) {
                for (int col = 0; col < 8; col++) {
                    if (piezas[fila][col] != jugador) continue;
                    for (int destinoFila = 0; destinoFila < 8; destinoFila++) {
                        for (int destinoCol = 0; destinoCol < 8; destinoCol++) {
                            if (esMovimientoLegal(fila, col, destinoFila, destinoCol, jugador)) return true;
                        }
                    }
                }
            }
            return false;
        }

        private boolean esMovimientoLegal(int fila, int col, int destinoFila, int destinoCol, int jugador) {
            int deltaFila = destinoFila - fila;
            int deltaCol = destinoCol - col;
            if ((deltaFila == 0 && deltaCol == 0)
                    || (deltaFila != 0 && deltaCol != 0
                    && Math.abs(deltaFila) != Math.abs(deltaCol))
                    || piezas[destinoFila][destinoCol] == jugador) return false;
            int pasoFila = Integer.compare(deltaFila, 0);
            int pasoCol = Integer.compare(deltaCol, 0);
            int revisarFila = fila + pasoFila;
            int revisarCol = col + pasoCol;
            while (revisarFila != destinoFila || revisarCol != destinoCol) {
                if (piezas[revisarFila][revisarCol] != 0) return false;
                revisarFila += pasoFila;
                revisarCol += pasoCol;
            }
            return true;
        }

        private int[][] movimientosLegales(int fila, int col) {
            int[][] destinos = new int[8][8];
            for (int destinoFila = 0; destinoFila < 8; destinoFila++) {
                for (int destinoCol = 0; destinoCol < 8; destinoCol++) {
                    if (esMovimientoLegal(fila, col, destinoFila, destinoCol, turno)) {
                        destinos[destinoFila][destinoCol] = 1;
                    }
                }
            }
            return destinos;
        }

        private void actualizarEstado() {
            if (ganador == 0) {
                estado.setText("Turno de " + (turno == 1 ? "Blancas" : "Negras")
                        + "  ·  Blancas: " + contarPiezas(1)
                        + "  ·  Negras: " + contarPiezas(-1) + "  ·  " + mensaje);
            } else {
                estado.setText(mensaje + "  ·  Blancas: " + contarPiezas(1)
                        + "  ·  Negras: " + contarPiezas(-1));
            }
        }

        private int[][] clonarTablero(int[][] original) {
            int[][] copia = new int[original.length][];
            for (int fila = 0; fila < original.length; fila++) copia[fila] = original[fila].clone();
            return copia;
        }

        private class DueloTablero extends JPanel {
            private PaletaTablero paleta = PALETAS.get(0);
            private int seleccionFila = -1;
            private int seleccionCol = -1;
            private int destinoFila = -1;
            private int destinoCol = -1;
            private int tamanoIcono = -1;
            private BufferedImage iconoEscalado;
            private long inicioAnimacion;
            private final Timer animacion = new Timer(16, e -> {
                if (System.nanoTime() - inicioAnimacion >= 300_000_000L) detenerAnimacion();
                repaint();
            });

            DueloTablero() {
                setOpaque(true);
                setBackground(new Color(0xE7EFE9));
                setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
                addMouseListener(new java.awt.event.MouseAdapter() {
                    @Override
                    public void mousePressed(java.awt.event.MouseEvent evento) {
                        int[] casilla = casillaEn(evento.getX(), evento.getY());
                        clicEnCasilla(casilla[0], casilla[1]);
                    }
                });
            }

            void setPaleta(PaletaTablero nuevaPaleta) {
                paleta = nuevaPaleta;
                repaint();
            }

            boolean animacionActiva() {
                return animacion.isRunning();
            }

            void animarMovimiento(int origenFila, int origenCol, int nuevaFila, int nuevaCol) {
                seleccionFila = origenFila;
                seleccionCol = origenCol;
                destinoFila = nuevaFila;
                destinoCol = nuevaCol;
                inicioAnimacion = System.nanoTime();
                animacion.start();
            }

            void detenerAnimacion() {
                animacion.stop();
                seleccionFila = -1;
                seleccionCol = -1;
                destinoFila = -1;
                destinoCol = -1;
                repaint();
            }

            private int[] casillaEn(int x, int y) {
                int casilla = Math.max(1, Math.min(getWidth() - 46, getHeight() - 46) / 8);
                int x0 = (getWidth() - casilla * 8) / 2;
                int y0 = (getHeight() - casilla * 8) / 2;
                int col = (x - x0) / casilla;
                int fila = (y - y0) / casilla;
                if (x < x0 || y < y0 || fila < 0 || fila >= 8 || col < 0 || col >= 8) {
                    return new int[]{-1, -1};
                }
                return new int[]{fila, col};
            }

            @Override
            protected void paintComponent(Graphics g0) {
                super.paintComponent(g0);
                Graphics2D g = (Graphics2D) g0.create();
                g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
                int cs = Math.max(1, Math.min(getWidth() - 46, getHeight() - 46) / 8);
                int x0 = (getWidth() - cs * 8) / 2;
                int y0 = (getHeight() - cs * 8) / 2;
                for (int fila = 0; fila < 8; fila++) {
                    for (int col = 0; col < 8; col++) {
                        g.setColor((fila + col) % 2 == 0 ? paleta.clara() : paleta.oscura());
                        g.fillRect(x0 + col * cs, y0 + fila * cs, cs, cs);
                    }
                }

                if (filaSeleccionada >= 0) {
                    int[][] destinos = movimientosLegales(filaSeleccionada, colSeleccionada);
                    for (int fila = 0; fila < 8; fila++) {
                        for (int col = 0; col < 8; col++) {
                            if (destinos[fila][col] == 0) continue;
                            int centroX = x0 + col * cs + cs / 2;
                            int centroY = y0 + fila * cs + cs / 2;
                            if (piezas[fila][col] == -turno) {
                                g.setColor(new Color(0xB8D1495B, true));
                                g.setStroke(new BasicStroke(Math.max(3f, cs * 0.07f)));
                                g.drawOval(x0 + col * cs + 4, y0 + fila * cs + 4, cs - 8, cs - 8);
                            } else {
                                g.setColor(new Color(0x990F5132, true));
                                int radio = Math.max(5, cs / 9);
                                g.fillOval(centroX - radio, centroY - radio, radio * 2, radio * 2);
                            }
                        }
                    }
                    g.setColor(new Color(0xFFF4A261));
                    g.setStroke(new BasicStroke(Math.max(2f, cs * 0.045f)));
                    g.drawRoundRect(x0 + colSeleccionada * cs + 2,
                            y0 + filaSeleccionada * cs + 2, cs - 4, cs - 4, 8, 8);
                }

                double progreso = animacion.isRunning()
                        ? Math.min(1d, (System.nanoTime() - inicioAnimacion) / 300_000_000d) : 1d;
                double movimiento = 1d - Math.pow(1d - progreso, 3d);
                for (int fila = 0; fila < 8; fila++) {
                    for (int col = 0; col < 8; col++) {
                        int pieza = piezas[fila][col];
                        if (pieza == 0 || animacion.isRunning()
                                && fila == destinoFila && col == destinoCol) continue;
                        dibujarReina(g, x0 + col * cs, y0 + fila * cs, cs, pieza);
                    }
                }
                if (animacion.isRunning()) {
                    int x = (int) Math.round(x0 + (seleccionCol
                            + (destinoCol - seleccionCol) * movimiento) * cs);
                    int y = (int) Math.round(y0 + (seleccionFila
                            + (destinoFila - seleccionFila) * movimiento) * cs);
                    dibujarReina(g, x, y, cs, piezas[destinoFila][destinoCol]);
                }

                g.setColor(AZUL_OSCURO);
                g.setStroke(new BasicStroke(2f));
                g.drawRect(x0, y0, cs * 8, cs * 8);
                g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, Math.max(10, cs / 6)));
                for (int i = 0; i < 8; i++) {
                    g.drawString(Integer.toString(8 - i), x0 - 18, y0 + i * cs + cs / 2 + 5);
                    g.drawString(Character.toString((char) ('a' + i)),
                            x0 + i * cs + cs / 2 - 4, y0 + cs * 8 + 17);
                }
                g.dispose();
            }

            private void dibujarReina(Graphics2D g, int x, int y, int cs, int jugador) {
                Color fondo = jugador == 1 ? new Color(0xFFF6DA) : new Color(0x25324A);
                Color borde = jugador == 1 ? new Color(0x9A6A24) : new Color(0xC8D3E6);
                int margen = Math.max(4, cs / 9);
                g.setColor(fondo);
                g.fillOval(x + margen, y + margen, cs - margen * 2, cs - margen * 2);
                g.setColor(borde);
                g.setStroke(new BasicStroke(Math.max(1.5f, cs * 0.035f)));
                g.drawOval(x + margen, y + margen, cs - margen * 2, cs - margen * 2);
                int icono = cs - margen * 3;
                if (tamanoIcono != icono) {
                    iconoEscalado = new BufferedImage(icono, icono, BufferedImage.TYPE_INT_ARGB);
                    Graphics2D escala = iconoEscalado.createGraphics();
                    escala.setRenderingHint(RenderingHints.KEY_INTERPOLATION,
                            RenderingHints.VALUE_INTERPOLATION_BICUBIC);
                    escala.drawImage(ICONO_REINA, 0, 0, icono, icono, null);
                    escala.dispose();
                    tamanoIcono = icono;
                }
                g.drawImage(iconoEscalado, x + (cs - icono) / 2, y + (cs - icono) / 2, null);
            }
        }
    }

    // ------------------------------------------------------------- control
    private void reiniciar() {
        detenerReproduccion();
        accionesReveladas = false;
        int n = (Integer) cmbN.getSelectedItem();
        ejecucion = new Ejecucion(n);
        int[] vacio = new int[n];
        Arrays.fill(vacio, -1);
        estadoInicioPrincipal = new Estado(n, vacio, new String[n], Tipo.INICIO, -1, -1, -1, -1,
                "Tablero vacío de " + n + "x" + n + ". Ninguna fila tiene reina (-1).\n\n"
                        + "Pulsa «Siguiente paso» o «Reproducir» para que el algoritmo evalúe la primera casilla.",
                codigoDe(Tipo.INICIO, -1, -1), 0, 0, 0, 0);
        mostrar(estadoInicioPrincipal);
        btnSiguiente.setEnabled(true);
        btnAnterior.setEnabled(false);
        btnAuto.setEnabled(true);
    }

    private class MiniSimulacion extends JPanel {
        private final Tablero miniTablero = new Tablero();
        private final JLabel estado = new JLabel("Elige un tamaño para explorar su recorrido.");
        private final RepresentacionReinas representacion = new RepresentacionReinas();
        private final JLabel metricas = new JLabel("Intentos 0  ·  Conflictos 0  ·  Retrocesos 0");
        private final JTextArea explicacion = new JTextArea();
        private final JTextArea codigo = new JTextArea();
        private final JTextArea historial = new JTextArea();
        private final JButton paso = new JButton("Siguiente paso");
        private final JButton pasoAnterior = new JButton("← Anterior");
        private final JButton reproducir = new JButton("▶ Reproducir");
        private final JButton reiniciarMini = new JButton("Reiniciar");
        private final JProgressBar avancePasos = new JProgressBar();
        private final Timer reloj = new Timer(850, e -> avanzar());
        private Ejecucion corrida;
        private Estado estadoInicial;
        private int n = -1;
        private boolean pasosRevelados;

        MiniSimulacion() {
            setLayout(new BorderLayout(6, 6));
            setBackground(Color.WHITE);
            setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(new Color(0xCBD5E1)),
                    new EmptyBorder(8, 8, 8, 8)));
            setPreferredSize(new Dimension(850, 370));
            setMaximumSize(new Dimension(Integer.MAX_VALUE, 410));

            estado.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 14));
            estado.setForeground(AZUL_OSCURO);
            estado.setOpaque(true);
            estado.setBackground(new Color(0xF1E8D5));
            estado.setBorder(new EmptyBorder(7, 9, 7, 9));
            JPanel barraEstado = new JPanel(new BorderLayout());
            barraEstado.setOpaque(false);
            barraEstado.add(estado, BorderLayout.CENTER);
            JPanel controles = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 3));
            controles.setOpaque(false);
            estilizarBoton(paso, new Color(0x6B7F3E));
            estilizarBoton(pasoAnterior, new Color(0x625D50));
            estilizarBoton(reproducir, new Color(0x3A5F40));
            estilizarBoton(reiniciarMini, new Color(0x6B6250));
            paso.setText("Siguiente paso  →");
            paso.setToolTipText("Avanza un paso de esta simulación independiente.");
            reproducir.setToolTipText("Reproduce o pausa el recorrido del caso seleccionado.");
            reiniciarMini.setToolTipText("Vuelve al tablero vacío de este caso.");
            paso.setEnabled(false);
            pasoAnterior.setEnabled(false);
            reproducir.setEnabled(false);
            reiniciarMini.setEnabled(false);
            controles.add(paso);
            controles.add(pasoAnterior);
            controles.add(reproducir);
            controles.add(reiniciarMini);
            barraEstado.add(controles, BorderLayout.SOUTH);
            avancePasos.setStringPainted(true);
            avancePasos.setString("");
            avancePasos.setForeground(new Color(0x3A5F40));
            avancePasos.setBackground(new Color(0xE4E9DD));
            avancePasos.setBorderPainted(false);
            avancePasos.setPreferredSize(new Dimension(100, 23));
            avancePasos.setVisible(false);
            barraEstado.add(avancePasos, BorderLayout.NORTH);
            add(barraEstado, BorderLayout.NORTH);

            miniTablero.setPreferredSize(new Dimension(500, 500));
            JPanel visual = new JPanel(new BorderLayout());
            visual.setOpaque(false);
            visual.add(miniTablero, BorderLayout.CENTER);
            visual.setMinimumSize(new Dimension(360, 320));

            metricas.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 14));
            metricas.setForeground(new Color(0x0F5132));
            metricas.setOpaque(true);
            metricas.setBackground(new Color(0xEAF3F0));
            metricas.setBorder(new EmptyBorder(6, 8, 6, 8));
            metricas.setHorizontalAlignment(SwingConstants.CENTER);
            explicacion.setEditable(false);
            explicacion.setLineWrap(true);
            explicacion.setWrapStyleWord(true);
            explicacion.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 15));
            explicacion.setMargin(new Insets(9, 10, 9, 10));
            codigo.setEditable(false);
            codigo.setLineWrap(true);
            codigo.setWrapStyleWord(true);
            codigo.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 14));
            codigo.setBackground(new Color(0x172033));
            codigo.setForeground(new Color(0xE2E8F0));
            codigo.setMargin(new Insets(9, 10, 9, 10));
            JPanel detalle = new JPanel(new BorderLayout(3, 3));
            detalle.setOpaque(false);
            JPanel resumen = new JPanel(new GridLayout(0, 1, 4, 4));
            resumen.setOpaque(false);
            resumen.add(representacion);
            representacion.setPreferredSize(new Dimension(300, 82));
            resumen.add(metricas);
            detalle.add(resumen, BorderLayout.NORTH);
            JSplitPane textos = new JSplitPane(JSplitPane.VERTICAL_SPLIT,
                    new JScrollPane(explicacion), new JScrollPane(codigo));
            textos.setResizeWeight(0.53);
            textos.setBorder(null);
            detalle.add(textos, BorderLayout.CENTER);
            JSplitPane escenario = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, visual, detalle);
            escenario.setResizeWeight(0.50);
            escenario.setBorder(null);
            fijarDivisorAlPrimerLayout(escenario, 0.50);
            fijarDivisorAlPrimerLayout(textos, 0.58);
            add(escenario, BorderLayout.CENTER);

            historial.setEditable(false);
            historial.setLineWrap(true);
            historial.setWrapStyleWord(true);
            historial.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 14));
            JScrollPane registro = new JScrollPane(historial);
            registro.setBorder(BorderFactory.createTitledBorder("Pasos ejecutados"));
            registro.setPreferredSize(new Dimension(420, 86));
            add(registro, BorderLayout.SOUTH);

            paso.addActionListener(e -> avanzar());
            pasoAnterior.addActionListener(e -> retroceder());
            reproducir.addActionListener(e -> alternarReproduccion());
            reiniciarMini.addActionListener(e -> {
                if (n > 0) iniciar(n);
            });
        }

        void setRitmo(int demora) {
            reloj.setDelay(demora);
            reloj.setInitialDelay(demora);
        }

        void setHeatmapActivo(boolean activo) {
            miniTablero.setHeatmapActivo(activo);
        }

        void setPaleta(PaletaTablero paleta) {
            miniTablero.setPaleta(paleta);
        }

        void iniciar(int nuevoN) {
            reloj.stop();
            pasosRevelados = false;
            reproducir.setText("▶ Reproducir");
            avancePasos.setIndeterminate(false);
            avancePasos.setValue(0);
            avancePasos.setString("");
            avancePasos.setVisible(false);
            n = nuevoN;
            historial.setText("");
            estado.setText("N=" + n + " · listo para iniciar");
            reiniciarMini.setEnabled(true);
            paso.setEnabled(true);
            reproducir.setEnabled(true);

            corrida = new Ejecucion(n);
            avancePasos.setMinimum(0);
            avancePasos.setMaximum(1);

            int[] vacio = new int[n];
            Arrays.fill(vacio, -1);
            estadoInicial = new Estado(n, vacio, new String[n], Tipo.INICIO, -1, -1, -1, -1,
                    "Tablero vacío de " + n + "x" + n + ". Cada fila está representada por una posición de reinas[].",
                    codigoDe(Tipo.INICIO, -1, -1), 0, 0, 0, 0);
            mostrar(estadoInicial);
        }

        private void avanzar() {
            if (corrida == null || !paso.isEnabled()) return;
            Estado siguiente = corrida.siguienteEstado();
            if (siguiente != null) mostrar(siguiente);
        }

        private void retroceder() {
            if (corrida == null) return;
            reloj.stop();
            reproducir.setText("▶ Reproducir");
            Estado anterior = corrida.estadoAnterior(estadoInicial);
            if (anterior != null) {
                mostrar(anterior);
                historial.setText("");
                for (Estado recorrido : corrida.estadosConsumidos()) agregarAlHistorial(recorrido);
            }
        }

        private void alternarReproduccion() {
            if (reloj.isRunning()) {
                reloj.stop();
                reproducir.setText("▶ Reproducir");
                actualizarBarraAvance(null);
            } else if (paso.isEnabled()) {
                reproducir.setText("Ⅱ Pausar");
                reloj.start();
                avanzar();
            }
        }

        private void mostrar(Estado e) {
            miniTablero.setEstado(e);
            representacion.mostrar(e.reinas());
            metricas.setText("<html><div style='text-align:center'>"
                    + "REINAS " + contarReinas(e.reinas()) + "/" + e.n()
                    + " &nbsp; · &nbsp; INTENTOS " + e.intentos()
                    + "<br>CONFLICTOS " + e.conflictos()
                    + " &nbsp; · &nbsp; RETROCESOS " + e.retrocesos()
                    + "</div></html>");
            boolean fin = e.tipo() == Tipo.SOLUCION || e.tipo() == Tipo.SIN_SOLUCION;
            if (fin) pasosRevelados = true;
            estado.setText(etiquetaPaso(e, corrida.totalEstados(), pasosRevelados));
            if (fin) reloj.stop();
            actualizarBarraAvance(e);
            explicacion.setText(e.mensaje() + "\n\n" + resumenNombresReinas(e.nombresReinas()));
            explicacion.setCaretPosition(0);
            codigo.setText(e.codigo());
            codigo.setCaretPosition(0);
            if (e.tipo() != Tipo.INICIO) agregarAlHistorial(e);
            paso.setEnabled(!fin);
            pasoAnterior.setEnabled(e.paso() > 0);
            reproducir.setEnabled(!fin);
            if (fin) {
                reproducir.setText("▶ Reproducir");
                reproducir.setEnabled(false);
            }
        }

        private void actualizarBarraAvance(Estado e) {
            boolean enCurso = reloj.isRunning() && e != null
                    && e.tipo() != Tipo.SOLUCION && e.tipo() != Tipo.SIN_SOLUCION;
            avancePasos.setVisible(enCurso);
            avancePasos.setIndeterminate(enCurso);
            if (enCurso) {
                avancePasos.setString("Paso " + e.paso() + " · en curso");
            } else {
                avancePasos.setValue(0);
                avancePasos.setString("");
            }
        }

        private void agregarAlHistorial(Estado e) {
            historial.append("Paso " + e.paso() + " · " + tituloEstado(e) + "\n"
                    + Arrays.toString(e.reinas()) + " — "
                    + e.mensaje().replace('\n', ' ') + "\n\n");
            historial.setCaretPosition(historial.getDocument().getLength());
        }

    }

    private void avanzar() {
        if (ejecucion == null || !btnSiguiente.isEnabled()) return;
        Estado siguiente = ejecucion.siguienteEstado();
        if (siguiente != null) mostrar(siguiente);
    }

    private void alternarReproduccion() {
        if (temporizador.isRunning()) {
            detenerReproduccion();
        } else if (btnSiguiente.isEnabled()) {
            btnAuto.setText("Ⅱ Pausar");
            temporizador.start();
            avanzar();
        }
    }

    private void detenerReproduccion() {
        temporizador.stop();
        btnAuto.setText("▶ Reproducir");
    }

    private String tituloEstado(Estado e) {
        return switch (e.tipo()) {
            case INICIO -> "INICIO";
            case EVALUANDO -> "EVALUANDO (" + e.fila() + ", " + e.col() + ")";
            case COLOCADA -> "COLOCADA (" + e.fila() + ", " + e.col() + ")";
            case CONFLICTO -> "CONFLICTO (" + e.fila() + ", " + e.col() + ")";
            case RETROCESO -> "RETROCESO (" + e.fila() + ", " + e.col() + ")";
            case SOLUCION -> "SOLUCIÓN";
            case SIN_SOLUCION -> "SIN SOLUCIÓN";
        };
    }

    private String etiquetaPaso(Estado estado, int total, boolean revelarTotal) {
        if (estado.tipo() == Tipo.INICIO) {
            return revelarTotal
                    ? "N=" + estado.n() + " · Total del recorrido: " + total + " pasos · Inicio"
                    : "N=" + estado.n() + " · Listo para iniciar";
        }
        String progreso = revelarTotal
                ? "Paso " + estado.paso() + " de " + total
                : "Paso " + estado.paso();
        if (estado.tipo() == Tipo.SOLUCION || estado.tipo() == Tipo.SIN_SOLUCION) {
            progreso = "Recorrido finalizado · " + total + " pasos";
        }
        return "N=" + estado.n() + " · " + progreso;
    }

    private void mostrar(Estado e) {
        ultimoEstadoPrincipal = e;
        tablero.setEstado(e);
        representacionReinas.mostrar(e.reinas());
        int reinasColocadas = contarReinas(e.reinas());
        barraProgreso.setMaximum(e.n());
        barraProgreso.setValue(reinasColocadas);
        barraProgreso.setString(reinasColocadas + " / " + e.n());
        boolean fin = e.tipo() == Tipo.SOLUCION || e.tipo() == Tipo.SIN_SOLUCION;
        if (fin) accionesReveladas = true;
        lblPaso.setText(etiquetaPaso(e, ejecucion.totalEstados(), accionesReveladas));
        lblTableroEstado.setText(e.n() + " × " + e.n());
        lblMetricas.setText("<html><div style='text-align:center'>"
                + "INTENTOS " + e.intentos()
                + "<br>CONFLICTOS " + e.conflictos()
                + " &nbsp; · &nbsp; RETROCESOS " + e.retrocesos()
                + "</div></html>");
        txtExplicacion.setText(e.mensaje()
                + "\n\n" + resumenNombresReinas(e.nombresReinas()));
        txtExplicacion.setCaretPosition(0);
        txtCodigo.setText(e.codigo());
        txtCodigo.setCaretPosition(0);
        btnSiguiente.setEnabled(!fin);
        btnAnterior.setEnabled(e.paso() > 0);
        btnAuto.setEnabled(!fin);
        if (fin) detenerReproduccion();
        actualizarCotas(selectorNComplejidad);
    }

    private static int contarReinas(int[] reinas) {
        int total = 0;
        for (int columna : reinas) if (columna >= 0) total++;
        return total;
    }

    private class RepresentacionReinas extends JPanel {
        private final JPanel celdas = new JPanel(new GridLayout(2, 0, 5, 2));

        RepresentacionReinas() {
            super(new BorderLayout(4, 2));
            setOpaque(true);
            setBackground(Color.WHITE);
            setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(new Color(0xD8E0DA)),
                    new EmptyBorder(6, 9, 6, 9)));
            JLabel titulo = new JLabel("REPRESENTACIÓN · reinas[fila] = columna");
            titulo.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 12));
            titulo.setForeground(new Color(0x526944));
            JLabel guia = new JLabel(
                    "Índice = fila  ·  valor = columna  ·  −1 = fila sin reina",
                    SwingConstants.CENTER);
            guia.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 12));
            guia.setForeground(new Color(0x526078));
            celdas.setOpaque(false);
            add(titulo, BorderLayout.NORTH);
            add(celdas, BorderLayout.CENTER);
            add(guia, BorderLayout.SOUTH);
            setToolTipText("Cada índice representa una fila; el valor indica la columna de su reina.");
        }

        void mostrar(int[] reinas) {
            celdas.removeAll();
            for (int fila = 0; fila < reinas.length; fila++) {
                JLabel indice = new JLabel(Integer.toString(fila), SwingConstants.CENTER);
                indice.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 11));
                indice.setForeground(new Color(0x526078));
                celdas.add(indice);
            }
            for (int columna : reinas) {
                JLabel valor = new JLabel(Integer.toString(columna), SwingConstants.CENTER);
                valor.setFont(new Font(Font.MONOSPACED, Font.BOLD, 16));
                valor.setForeground(AZUL_OSCURO);
                valor.setOpaque(true);
                valor.setBackground(new Color(0xF1F4EE));
                valor.setBorder(BorderFactory.createLineBorder(new Color(0xD8E0DA)));
                celdas.add(valor);
            }
            celdas.revalidate();
            celdas.repaint();
        }
    }

    private static String codigoDe(Tipo tipo, int fila, int col) {
        return switch (tipo) {
            case INICIO -> "int[] reinas = new int[N];\n"
                    + "String[] nombresReinas = new String[N]; // solo identidad visual\n"
                    + "List<String> identidades = mezclar(NOMBRES_REINAS);\n"
                    + "int siguienteIdentidad = 0;\n"
                    + "int[] columnaPor = new int[N];\n"
                    + "int[] diagonalPor = new int[2 * N - 1];\n"
                    + "int[] antidiagonalPor = new int[2 * N - 1];\n"
                    + "Arrays.fill(reinas, -1);\n"
                    + "Arrays.fill(columnaPor, -1);\n"
                    + "Arrays.fill(diagonalPor, -1);\n"
                    + "Arrays.fill(antidiagonalPor, -1);";
            case EVALUANDO -> "for (int col = 0; col < N; col++) {\n"
                    + "    int choque = conflicto(" + fila + ", " + col + ");\n"
                    + "    // -1 = libre; si no, (choque >>> 1) es la fila y (choque & 1) el tipo.\n"
                    + "    if (choque != -1) continue; // probar la siguiente columna";
            case COLOCADA -> "if (choque == -1) {\n"
                    + "    reinas[" + fila + "] = " + col + ";\n"
                    + "    nombresReinas[" + fila + "] = identidades.get(siguienteIdentidad++);\n"
                    + "    columnaPor[" + col + "] = " + fila + ";\n"
                    + "    diagonalPor[fila - col + N - 1] = " + fila + ";\n"
                    + "    antidiagonalPor[fila + col] = " + fila + ";\n"
                    + "    // Identidad visual única en esta simulación.\n"
                    + "    if (resolver(" + (fila + 1) + ")) return true;";
            case CONFLICTO -> "int choque = conflicto(" + fila + ", " + col + ");\n"
                    + "if (choque != -1) {\n"
                    + "    int filaConflicto = choque >>> 1;\n"
                    + "    boolean mismaColumna = (choque & 1) == 0;\n"
                    + "    continue; // probar la siguiente columna";
            case RETROCESO -> "if (resolver(" + (fila + 1) + ")) return true;\n"
                    + "reinas[" + fila + "] = -1;\n"
                    + "nombresReinas[" + fila + "] = null;\n"
                    + "columnaPor[" + col + "] = -1;\n"
                    + "diagonalPor[fila - col + N - 1] = -1;\n"
                    + "antidiagonalPor[fila + col] = -1;\n"
                    + "// siguienteIdentidad no retrocede: no repetir nombres usados.";
            case SOLUCION -> "if (fila == N) {\n"
                    + "    return true; // todas las filas tienen una reina segura\n"
                    + "}";
            case SIN_SOLUCION -> "boolean haySolucion = resolver(0);\n"
                    + "if (!haySolucion) {\n"
                    + "    // La búsqueda se agotó: no se encontró una solución.\n"
                    + "}";
        };
    }

    // ===================================================================
    //  ALGORITMO: backtracking recursivo con avance visual por estados
    // ===================================================================
    class Ejecucion {
        final int n;
        final String[] nombresReinas;
        final int[] reinas;                          // reinas[fila] = columna (-1 = vacía)
        final int[] columnaPor;
        final int[] diagonalPor;
        final int[] antidiagonalPor;
        private final List<Estado> estados = new ArrayList<>();
        private final List<String> identidadesDisponibles = new ArrayList<>(NOMBRES_REINAS);
        private int indiceEstado;
        private int siguienteIdentidad;
        int pasos = 0;
        int intentos = 0;
        int conflictos = 0;
        int retrocesos = 0;

        Ejecucion(int n) {
            this.n = n;
            this.reinas = new int[n];
            this.nombresReinas = new String[n];
            this.columnaPor = new int[n];
            this.diagonalPor = new int[2 * n - 1];
            this.antidiagonalPor = new int[2 * n - 1];
            Arrays.fill(reinas, -1);
            Arrays.fill(columnaPor, -1);
            Arrays.fill(diagonalPor, -1);
            Arrays.fill(antidiagonalPor, -1);
            Collections.shuffle(identidadesDisponibles, ThreadLocalRandom.current());
            if (!resolver(0)) {
                guardarEstado(Tipo.SIN_SOLUCION, -1, -1, -1, -1,
                        "La búsqueda recorrió todas las alternativas compatibles y no encontró una "
                                + "colocación completa.\n\n"
                                + "resolver(0) devuelve false: no existe solución para N=" + n + ". "
                                + "La ausencia de solución es un resultado válido, no un error.");
            }
        }

        Estado siguienteEstado() {
            return indiceEstado < estados.size() ? estados.get(indiceEstado++) : null;
        }

        Estado estadoAnterior(Estado inicial) {
            if (indiceEstado <= 0) return null;
            if (indiceEstado == 1) {
                indiceEstado = 0;
                return inicial;
            }
            indiceEstado--;
            return estados.get(indiceEstado - 1);
        }

        List<Estado> estadosConsumidos() {
            return List.copyOf(estados.subList(0, indiceEstado));
        }

        int totalEstados() {
            return estados.size();
        }

        /** Recursión clásica de backtracking. Devuelve true si encontró una solución completa. */
        boolean resolver(int fila) {
            if (fila == n) {                         // caso base: todas las filas tienen reina
                guardarEstado(Tipo.SOLUCION, -1, -1, -1, -1,
                        "Primera solución encontrada · reinas[fila] = columna = "
                                + Arrays.toString(reinas) + ".\n\n"
                                + "Cada fila y columna contiene una reina y ninguna pareja comparte diagonal. "
                                + "resolver(N) alcanza el caso base; true se propaga hasta resolver(0) "
                                + "y la búsqueda se detiene."
                                + (n == 1 ? "\n\nN=1: se coloca la única reina y no hay piezas previas que comprobar." : ""));
                return true;
            }
            for (int col = 0; col < n; col++) {
                intentos++;
                guardarEstado(Tipo.EVALUANDO, fila, col, -1, -1,
                        "Evalúo la casilla (" + fila + ", " + col + "). INTENTOS aumenta porque esta "
                                + "candidata se está examinando.\n"
                                + (fila == 0
                                ? "Todavía no hay reinas colocadas: la primera candidata de la fila 0 es segura."
                                : "Compruebo la columna y las dos diagonales contra las "
                                + fila + " reinas ya colocadas. Si alguna marca está ocupada, la descarto."));

                int choque = conflicto(fila, col);
                if (choque == -1) {
                    if (siguienteIdentidad >= identidadesDisponibles.size()) {
                        throw new IllegalStateException(
                                "Se agotaron los nombres históricos únicos antes de completar la simulación.");
                    }
                    reinas[fila] = col;
                    nombresReinas[fila] = identidadesDisponibles.get(siguienteIdentidad++);
                    columnaPor[col] = fila;
                    diagonalPor[indiceDiagonal(fila, col)] = fila;
                    antidiagonalPor[fila + col] = fila;
                    guardarEstado(Tipo.COLOCADA, fila, col, -1, -1,
                            "La candidata (" + fila + ", " + col + ") no comparte columna ni diagonal "
                                    + "con las reinas anteriores. Se coloca y se actualiza reinas["
                                    + fila + "] = " + col + ".\n"
                                    + "La identidad visual " + nombresReinas[fila]
                                    + " solo sirve para distinguir la pieza; no participa en las reglas.\n\n"
                                    + (fila + 1 == n
                                    ? "Todas las filas ya tienen reina: resolver(" + n + ") alcanza el caso base."
                                    : "La recursión pasa a la fila " + (fila + 1) + " para buscar una continuación."));
                    if (resolver(fila + 1)) return true;

                    // La recursión devolvió false: esta reina lleva a un callejón sin salida.
                    retrocesos++;
                    guardarEstado(Tipo.RETROCESO, fila, col, -1, -1,
                            "La fila " + (fila + 1) + " agotó sus columnas seguras. La decisión en ("
                                    + fila + ", " + col + ") no permite completar el tablero.\n"
                                    + "Retiro la reina, restablezco sus marcas y reinas[" + fila + "] = -1.\n\n"
                                    + (col + 1 < n
                                    ? "Continúo con la columna " + (col + 1) + " de la fila " + fila + "."
                                    : "Ya se probaron todas las columnas de la fila " + fila
                                    + "; la llamada devuelve false a la fila anterior."));
                    reinas[fila] = -1;               // deshacer la decisión
                    nombresReinas[fila] = null;
                    columnaPor[col] = -1;
                    diagonalPor[indiceDiagonal(fila, col)] = -1;
                    antidiagonalPor[fila + col] = -1;
                } else {
                    conflictos++;
                    int r = choque >>> 1;
                    int rc = reinas[r];
                    String motivo = (choque & 1) == 0
                            ? "la misma columna que la reina de (" + r + ", " + rc + ")."
                            : "la misma diagonal que la reina de (" + r + ", " + rc + "): |" + rc + " - " + col
                            + "| = " + Math.abs(rc - col) + " es igual a la distancia de filas " + (fila - r) + ".";
                    guardarEstado(Tipo.CONFLICTO, fila, col, r, rc,
                            "La casilla (" + fila + ", " + col + ") no es segura: comparte " + motivo
                                    + "\nLa candidata se descarta; no modifica el tablero ni sus marcas.\n\n"
                                    + (col + 1 < n
                                    ? "Siguiente: comprobar la columna " + (col + 1) + " de la fila " + fila + "."
                                    : "Era la última columna de la fila " + fila
                                    + "; si no hay otra candidata segura, la llamada retrocede."));
                }
            }
            return false;                            // ninguna columna sirvió -> retroceder
        }

        /** Devuelve -1 si no hay conflicto; si lo hay, codifica fila y tipo en un entero. */
        int conflicto(int fila, int col) {
            if (columnaPor[col] >= 0) return columnaPor[col] << 1;
            int diagonal = diagonalPor[indiceDiagonal(fila, col)];
            if (diagonal >= 0) return diagonal << 1 | 1;
            int antidiagonal = antidiagonalPor[fila + col];
            if (antidiagonal >= 0) return antidiagonal << 1 | 1;
            return -1;
        }

        int indiceDiagonal(int fila, int col) {
            return fila - col + n - 1;
        }

        /** Guarda una instantánea inmutable para reproducirla sin bloquear Swing. */
        void guardarEstado(Tipo tipo, int fila, int col, int otraFila, int otraCol, String mensaje) {
            final Estado e = new Estado(n, reinas.clone(), nombresReinas.clone(),
                    tipo, fila, col, otraFila, otraCol,
                    mensaje, codigoDe(tipo, fila, col), ++pasos, intentos, conflictos, retrocesos);
            estados.add(e);
        }
    }

    // ===================================================================
    //  TABLERO (dibujo)
    // ===================================================================
    static class Tablero extends JPanel {
        private Estado e;
        private PaletaTablero paleta = PALETAS.get(0);
        private int hoverFila = -1;
        private int hoverCol = -1;
        private boolean heatmapActivo = true;
        private int efectoTicks;
        private Tipo tipoEfecto;
        private int tamanoIcono = -1;
        private BufferedImage iconoEscalado;
        private final Timer temporizadorEfecto;

        Tablero() {
            temporizadorEfecto = new Timer(55, evento -> {
                efectoTicks--;
                if (efectoTicks <= 0) ((Timer) evento.getSource()).stop();
                repaint();
            });
            setPreferredSize(new Dimension(600, 600));
            setBackground(new Color(0xE7EFE9));
            setToolTipText("");
            addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
                @Override
                public void mouseMoved(java.awt.event.MouseEvent evento) {
                    int[] casilla = casillaEn(evento.getX(), evento.getY());
                    int fila = casilla[0];
                    int col = casilla[1];
                    if (e != null && fila >= 0 && e.reinas()[fila] == col) {
                        hoverFila = fila;
                        hoverCol = col;
                    } else {
                        hoverFila = -1;
                        hoverCol = -1;
                    }
                    repaint();
                }
            });
            addMouseListener(new java.awt.event.MouseAdapter() {
                @Override
                public void mouseExited(java.awt.event.MouseEvent evento) {
                    hoverFila = -1;
                    hoverCol = -1;
                    repaint();
                }
            });
        }

        @Override
        public String getToolTipText(java.awt.event.MouseEvent evento) {
            int[] casilla = casillaEn(evento.getX(), evento.getY());
            int fila = casilla[0];
            int col = casilla[1];
            if (e == null || fila < 0 || e.reinas()[fila] != col
                    || e.nombresReinas()[fila] == null) return null;
            return "Fila " + (fila + 1) + " · columna " + (col + 1)
                    + " · " + e.nombresReinas()[fila];
        }

        private int[] casillaEn(int x, int y) {
            if (e == null) return new int[]{-1, -1};
            int n = e.n();
            int cs = Math.max(1, (Math.min(getWidth(), getHeight()) - 40) / n);
            int x0 = (getWidth() - cs * n) / 2;
            int y0 = (getHeight() - cs * n) / 2;
            int col = (x - x0) / cs;
            int fila = (y - y0) / cs;
            if (x < x0 || y < y0 || fila < 0 || fila >= n || col < 0 || col >= n) {
                return new int[]{-1, -1};
            }
            return new int[]{fila, col};
        }

        void setEstado(Estado e) {
            this.e = e;
            if (e.tipo() == Tipo.EVALUANDO || e.tipo() == Tipo.CONFLICTO
                    || e.tipo() == Tipo.RETROCESO || e.tipo() == Tipo.COLOCADA
                    || e.tipo() == Tipo.SOLUCION) {
                tipoEfecto = e.tipo();
                efectoTicks = switch (e.tipo()) {
                    case COLOCADA -> 7;
                    case SOLUCION -> 18;
                    default -> 9;
                };
                if (!temporizadorEfecto.isRunning()) temporizadorEfecto.start();
            } else {
                temporizadorEfecto.stop();
                efectoTicks = 0;
                tipoEfecto = null;
            }
            repaint();
        }

        void setHeatmapActivo(boolean activo) {
            heatmapActivo = activo;
            repaint();
        }

        void setPaleta(PaletaTablero paleta) {
            this.paleta = paleta;
            repaint();
        }

        @Override
        protected void paintComponent(Graphics g0) {
            super.paintComponent(g0);
            if (e == null) return;
            Graphics2D g = (Graphics2D) g0;
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            if ((tipoEfecto == Tipo.CONFLICTO || tipoEfecto == Tipo.RETROCESO)
                    && efectoTicks > 0) {
                int sacudida = efectoTicks % 3 == 0 ? 2 : efectoTicks % 3 == 1 ? -2 : 0;
                g.translate(sacudida, 0);
            }

            int n = e.n();
            int cs = Math.max(1, (Math.min(getWidth(), getHeight()) - 40) / n);
            int x0 = (getWidth() - cs * n) / 2;
            int y0 = (getHeight() - cs * n) / 2;

            // 1) casillas alternadas + índices
            g.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 13));
            for (int f = 0; f < n; f++) {
                for (int c = 0; c < n; c++) {
                    g.setColor((f + c) % 2 == 0 ? paleta.clara() : paleta.oscura());
                    g.fillRect(x0 + c * cs, y0 + f * cs, cs, cs);
                }
                g.setColor(AZUL_OSCURO);
                String indiceFila = Integer.toString(f);
                g.drawString(indiceFila,
                        x0 - g.getFontMetrics().stringWidth(indiceFila) - 7,
                        y0 + f * cs + cs / 2 + 5);
                g.drawString(Integer.toString(f), x0 + f * cs + cs / 2 - 4, y0 - 9);
            }

            dibujarRangosAtaque(g, x0, y0, cs, n);

            // 2) reinas colocadas de forma segura
            for (int f = 0; f < n; f++) {
                if (e.reinas()[f] >= 0) {
                    celda(g, x0, y0, cs, f, e.reinas()[f], VERDE, "");
                    boolean afectada = e.tipo() == Tipo.CONFLICTO && f == e.otraFila()
                            || e.tipo() == Tipo.RETROCESO && f == e.fila();
                    dibujarReina(g, x0 + e.reinas()[f] * cs, y0 + f * cs, cs,
                            e.nombresReinas()[f], afectada,
                            tipoEfecto == Tipo.COLOCADA && f == e.fila() && efectoTicks > 0);
                }
            }

            // 3) casilla de la acción actual
            switch (e.tipo()) {
                case EVALUANDO -> celda(g, x0, y0, cs, e.fila(), e.col(), NARANJA, "?");
                case CONFLICTO -> {
                    g.setColor(ROJO);
                    g.setStroke(new BasicStroke(4f));
                    g.drawLine(x0 + e.otraCol() * cs + cs / 2, y0 + e.otraFila() * cs + cs / 2,
                            x0 + e.col() * cs + cs / 2, y0 + e.fila() * cs + cs / 2);
                    g.drawRect(x0 + e.otraCol() * cs + 3, y0 + e.otraFila() * cs + 3, cs - 6, cs - 6);
                    g.setStroke(new BasicStroke(1f));
                    celda(g, x0, y0, cs, e.fila(), e.col(), ROJO, "X");
                }
                case RETROCESO -> {
                    celda(g, x0, y0, cs, e.fila(), e.col(), ROJO, "");
                    dibujarReina(g, x0 + e.col() * cs, y0 + e.fila() * cs, cs,
                            e.nombresReinas()[e.fila()], true, false);
                }
                default -> { }
            }

            if (tipoEfecto == Tipo.CONFLICTO && efectoTicks > 0
                    && e.fila() >= 0 && e.col() >= 0) {
                float progreso = (9 - efectoTicks) / 9f;
                int radio = (int) (cs * (0.18 + progreso * 0.65));
                Graphics2D onda = (Graphics2D) g.create();
                onda.setComposite(AlphaComposite.SrcOver.derive(Math.max(0.08f, 0.62f * (1 - progreso))));
                onda.setColor(new Color(0xEF4444));
                onda.setStroke(new BasicStroke(Math.max(1.5f, cs * 0.035f)));
                int centroX = x0 + e.col() * cs + cs / 2;
                int centroY = y0 + e.fila() * cs + cs / 2;
                onda.drawOval(centroX - radio, centroY - radio, radio * 2, radio * 2);
                onda.dispose();
            }
            if (tipoEfecto == Tipo.EVALUANDO && efectoTicks > 0
                    && e.fila() >= 0 && e.col() >= 0) {
                float progreso = (9 - efectoTicks) / 9f;
                Graphics2D pulso = (Graphics2D) g.create();
                pulso.setComposite(AlphaComposite.SrcOver.derive(0.35f + 0.55f * (1 - progreso)));
                pulso.setColor(new Color(0xFFF4D6));
                pulso.setStroke(new BasicStroke(Math.max(1.5f, cs * 0.035f)));
                pulso.drawRoundRect(x0 + e.col() * cs + 4, y0 + e.fila() * cs + 4,
                        cs - 8, cs - 8, Math.max(6, cs / 5), Math.max(6, cs / 5));
                pulso.dispose();
            }

            // 4) marco del tablero
            g.setColor(AZUL_OSCURO);
            g.setStroke(new BasicStroke(2f));
            g.drawRect(x0, y0, cs * n, cs * n);
            if (tipoEfecto == Tipo.SOLUCION && efectoTicks > 0) {
                Graphics2D celebracion = (Graphics2D) g.create();
                celebracion.setComposite(AlphaComposite.SrcOver.derive(
                        Math.min(0.8f, efectoTicks / 18f)));
                celebracion.setColor(new Color(0xB7E4C7));
                celebracion.setStroke(new BasicStroke(Math.max(3f, cs * 0.08f)));
                celebracion.drawRect(x0 + 2, y0 + 2, cs * n - 4, cs * n - 4);
                celebracion.dispose();
            }
        }

        private void dibujarRangosAtaque(Graphics2D g, int x0, int y0, int cs, int n) {
            if (!heatmapActivo || hoverFila < 0 || hoverCol < 0
                    || e.reinas()[hoverFila] != hoverCol) return;
            Graphics2D rangos = (Graphics2D) g.create();
            rangos.setComposite(AlphaComposite.SrcOver.derive(0.25f));
            rangos.setColor(new Color(0xF97316));
            for (int fila = 0; fila < n; fila++) {
                for (int col = 0; col < n; col++) {
                    if (fila == hoverFila || col == hoverCol
                            || Math.abs(fila - hoverFila) == Math.abs(col - hoverCol)) {
                        rangos.fillRoundRect(x0 + col * cs + 2, y0 + fila * cs + 2,
                                cs - 4, cs - 4, 8, 8);
                    }
                }
            }
            rangos.dispose();
        }

        private void dibujarReina(Graphics2D g, int x, int y, int cs, String nombre,
                                   boolean afectada, boolean entrada) {
            int desplazamiento = 0;
            if (afectada && efectoTicks > 0) {
                desplazamiento = (int) Math.round(Math.sin((9 - efectoTicks) * 2.3)
                        * Math.min(5, cs / 12));
                Graphics2D alerta = (Graphics2D) g.create();
                alerta.setComposite(AlphaComposite.SrcOver.derive(
                        efectoTicks % 2 == 0 ? 0.46f : 0.20f));
                alerta.setColor(new Color(0xFF334F));
                alerta.fillRoundRect(x + 2, y + 2, cs - 4, cs - 4, 12, 12);
                alerta.dispose();
            }
            Graphics2D ficha = (Graphics2D) g.create();
            if (tamanoIcono != cs) {
                iconoEscalado = new BufferedImage(cs, cs, BufferedImage.TYPE_INT_ARGB);
                Graphics2D escala = iconoEscalado.createGraphics();
                escala.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
                escala.drawImage(ICONO_REINA, 0, 0, cs, cs, null);
                escala.dispose();
                tamanoIcono = cs;
            }
            int ladoIcono = cs;
            if (entrada) {
                float progreso = Math.max(0f, Math.min(1f, (8f - efectoTicks) / 7f));
                float suavizado = 1f - (float) Math.pow(1f - progreso, 3);
                float opacidad = 0.45f + 0.55f * suavizado;
                ficha.setComposite(AlphaComposite.SrcOver.derive(opacidad));
                ladoIcono = Math.round(cs * (0.72f + 0.28f * suavizado));
                int resplandor = (int) (cs * (0.12 + (7 - efectoTicks) * 0.035));
                ficha.setColor(new Color(0xF5C451));
                ficha.setStroke(new BasicStroke(Math.max(1f, cs * 0.025f)));
                ficha.drawOval(x + cs / 2 - resplandor, y + cs / 2 - resplandor,
                        resplandor * 2, resplandor * 2);
            }
            ficha.drawImage(iconoEscalado, x + desplazamiento + (cs - ladoIcono) / 2,
                    y + (cs - ladoIcono) / 2, ladoIcono, ladoIcono, null);
            ficha.dispose();
            if (nombre == null || cs < 34) return;
            int separador = nombre.indexOf(" — ");
            String nombrePropio = separador < 0 ? nombre : nombre.substring(0, separador);
            String etiqueta = nombrePropio.length() <= Math.max(5, cs / 7)
                    ? nombrePropio : nombrePropio.substring(0, Math.min(4, nombrePropio.length())) + "…";
            int fuente = Math.max(9, Math.min(12, cs / 6));
            Graphics2D placa = (Graphics2D) g.create();
            placa.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING,
                    RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            placa.setFont(new Font(Font.SANS_SERIF, Font.BOLD, fuente));
            FontMetrics medidas = placa.getFontMetrics();
            int ancho = Math.min(cs - 2, medidas.stringWidth(etiqueta) + 8);
            int xPlaca = x + (cs - ancho) / 2;
            int alto = medidas.getHeight() + 2;
            int yPlaca = y + cs - alto - 2;
            placa.setColor(new Color(0xDD173B35, true));
            placa.fillRoundRect(xPlaca, yPlaca, ancho, alto, 7, 7);
            placa.setColor(Color.WHITE);
            placa.drawString(etiqueta, x + (cs - medidas.stringWidth(etiqueta)) / 2,
                    yPlaca + medidas.getAscent() + 1);
            placa.dispose();
        }

        private void celda(Graphics2D g, int x0, int y0, int cs, int f, int c, Color fondo, String txt) {
            int x = x0 + c * cs, y = y0 + f * cs;
            g.setColor(fondo);
            g.fillRect(x + 1, y + 1, cs - 2, cs - 2);
            if (txt.isEmpty()) return;
            g.setColor(Color.WHITE);
            Font font = new Font(Font.SANS_SERIF, Font.BOLD, (int) (cs * 0.55));
            g.setFont(font);
            FontMetrics fm = g.getFontMetrics();
            g.drawString(txt, x + (cs - fm.stringWidth(txt)) / 2, y + (cs + fm.getAscent() - fm.getDescent()) / 2);
        }
    }

    // -------------------------------------------------------- contenido educativo
    static final String PSEUDOCODIGO = """
            BACKTRACKING · ENCONTRAR UNA CONFIGURACIÓN VÁLIDA

            PROCEDIMIENTO resolver(fila)
                SI fila = N:
                    DEVOLVER verdadero   // todas las filas ya tienen reina

                PARA columna DESDE 0 HASTA N - 1:
                    SI la columna o alguna diagonal está ocupada:
                        CONTINUAR         // descartar esta candidata

                    colocar la reina en (fila, columna)
                    marcar columna y las dos diagonales

                    SI resolver(fila + 1):
                        DEVOLVER verdadero

                    retirar la reina de (fila, columna)
                    liberar columna y las dos diagonales
                    // La siguiente vuelta prueba otra columna

                DEVOLVER falso             // ninguna alternativa completó el tablero

            CONEXIÓN CON LA ANIMACIÓN
            EVALUAR · La candidata ámbar aumenta INTENTOS; aún no está colocada.
            DESCARTAR · Rojo señala la reina atacante; aumenta CONFLICTOS.
            COLOCAR · La casilla segura actualiza los arreglos y avanza una fila.
            RETROCEDER · Se deshacen las marcas y se prueba otra alternativa.
            TERMINAR · true devuelve la primera solución; false agota las ramas.
            """;

    static final String COMPLEJIDAD = "COMPLEJIDAD";

    static final String FUENTES_CREDITOS = "FUENTES_CREDITOS";

    // --------------------------------------------------------------------- main
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new NReinas().setVisible(true));
    }
}