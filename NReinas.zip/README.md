# N Reinas · explorador visual de backtracking

Aplicación educativa de escritorio para seguir, paso a paso, cómo una búsqueda
prueba posiciones, descarta conflictos y retrocede hasta encontrar una solución
o demostrar que no existe. También incluye un duelo local para dos personas en
un tablero de ajedrez con reinas únicamente.

## Comenzar

Para preparar un ZIP ejecutable en Windows, ejecuta `package.bat`. Genera
`dist/NReinas.zip` con el JAR, el código fuente y los archivos necesarios para
recompilarlo. Después:

1. Extrae **todo** el contenido del ZIP en una carpeta.
2. Ejecuta `run.bat`.

Se necesita Java 17 o posterior. No hace falta conexión a Internet ni instalar
bibliotecas adicionales. `reina.png` se incluye dentro de `build/NReinas.jar`
como recurso del programa, así que no depende de la carpeta actual ni de una
ruta absoluta del equipo donde se creó el ZIP. El ZIP también incluye la imagen
junto al código fuente para poder recompilar. El JAR permite iniciar el programa
sin compilar; si falta, `run.bat` intenta generarlo con un JDK disponible.

## El problema, en breve

El objetivo es colocar N reinas en un tablero N×N de modo que ninguna pareja
comparta fila, columna o diagonal. El algoritmo asigna una reina por fila y
recorre las columnas de izquierda a derecha.

En el código, las coordenadas empiezan en cero. `reinas[fila]` guarda la columna
elegida para esa fila; `-1` significa que la fila está vacía. Tres arreglos
auxiliares registran columnas y diagonales ocupadas para comprobar cada
candidata con accesos directos.

## Recorrido de la aplicación

### Animación

Selecciona N entre 1 y 8 y avanza paso a paso o reproduce la búsqueda. El tablero,
la explicación y el fragmento de código se actualizan juntos. El objetivo y la
leyenda tienen funciones distintas: el primero resume las reglas del reto; la
leyenda identifica el significado de los colores:

- **Ámbar:** candidata que se está comprobando; todavía no está colocada.
- **Verde:** posición segura; se avanza a la fila siguiente.
- **Rojo:** conflicto o decisión que se deshace durante el retroceso.
- **Marco verde:** se encontró una solución.

La representación `reinas[fila] = columna` muestra el arreglo actual. Los ejes
del tablero y las coordenadas del código usan índices desde cero.

### Casos y ejemplos

Las simulaciones independientes muestran cuatro recorridos:

- **N=1:** caso base; la primera candidata completa el tablero.
- **N=2 y N=3:** no hay solución; se agotan las alternativas sin error.
- **N=4:** se observa un retroceso y una primera solución, `[1, 3, 0, 2]`.

Para N=4 existen dos soluciones; la búsqueda se detiene en la primera que
encuentra siguiendo el orden de las columnas.

### Big O

Separa el tamaño del árbol, el costo de comprobar una candidata y la memoria
extra que guarda las instantáneas de la animación. El gráfico compara una cota
superior de intentos con el recorrido observado; no representa segundos ni un
ahorro de tiempo.

### Pseudocódigo y créditos

El pseudocódigo explica el caso base, la elección de una candidata, la
comprobación y la restauración de las marcas. Los créditos reúnen las referencias
y materiales consultados.

## Controles y contadores

- **Siguiente paso / Anterior:** recorre o revisa una decisión.
- **Reproducir / Pausar:** inicia o detiene el recorrido automático.
- **Velocidad:** elige Lento, Normal, Rápido o Muy rápido.
- **Rangos de ataque:** al pasar el cursor sobre una reina, muestra su fila,
  columna y diagonales. La tecla **H** alterna esta ayuda.
- **Presentar:** alterna entre ventana normal y maximizada.
- **Paleta del tablero:** elige entre Clásica, Océano, Atardecer y Medianoche.
  El cambio se aplica a los tableros del explorador, los casos y el duelo.
- **Atajos:** **Espacio** avanza, **Flecha izquierda** retrocede y **M** cambia
  la velocidad.

La barra de progreso muestra cuántas reinas permanecen colocadas respecto de N.
Los contadores describen el trabajo de búsqueda:

- **Intentos:** candidatas examinadas, tanto seguras como atacadas.
- **Conflictos:** candidatas descartadas por compartir columna o diagonal.
- **Retrocesos:** decisiones retiradas cuando la búsqueda inferior no encuentra salida.

No sumes estos contadores como si midieran tiempo. Un paso visual documenta una
decisión del recorrido; no equivale necesariamente a una llamada recursiva.

## Duelo de reinas para dos personas

Abre la pestaña **06 · Duelo de reinas**. Blancas y Negras empiezan con ocho
reinas en sus filas iniciales y se turnan: selecciona una pieza y luego una
casilla marcada. Las reinas se mueven en línea recta o diagonal, no saltan
piezas y pueden capturar una reina rival. Gana quien capture todas las reinas
del otro lado; si el jugador al turno no tiene movimientos legales, la partida
termina en empate. No hay reyes ni reglas de jaque en esta variante.

**Nueva partida** restaura la posición inicial y **Deshacer** revierte el último
movimiento. Los desplazamientos se animan y las casillas posibles se resaltan
al seleccionar una reina.

## Archivos incluidos

- `NReinas.java`: interfaz, algoritmo y contenido educativo.
- `reina.png`: ilustración de las piezas; su fondo se vuelve transparente al cargarla.
- `build/NReinas.jar`: aplicación ejecutable compilada para Java 17.
- `run.bat`: inicia el JAR o intenta compilarlo si hace falta.
- `build.bat`: compila el proyecto y crea el JAR.
- `package.bat`: compila y crea el ZIP portable en `dist/NReinas.zip`.
- `README.md`: instrucciones, conceptos y controles.

## Compilar desde el código fuente

Para compilar hace falta un **JDK 17 o posterior**. Desde una terminal abierta
en la carpeta del proyecto, ejecuta `build.bat`, o bien:

```bat
if not exist build\classes mkdir build\classes
javac --release 17 -encoding UTF-8 -d build\classes NReinas.java
copy /Y reina.png build\classes\
jar --create --file build\NReinas.jar --main-class NReinas -C build\classes .
java -jar build\NReinas.jar
```

Conserva `reina.png` junto a `NReinas.java` al compilar manualmente: el programa
la carga como recurso incluido en el JAR.

## Si algo no funciona

- **`java` no se reconoce:** instala Java 17 o posterior y verifica que esté en
  `PATH`.
- **`javac` o `jar` no se reconoce:** instala un JDK; un entorno de ejecución
  por sí solo no incluye las herramientas de compilación.
- **La imagen no aparece al compilar manualmente:** confirma que `reina.png`
  esté junto a `NReinas.java` y repite la compilación.
