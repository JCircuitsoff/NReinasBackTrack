@echo off
setlocal
cd /d "%~dp0"

where javac >nul 2>nul
if errorlevel 1 (
    echo Error: se necesita un JDK 17 o posterior para compilar.
    echo Instala un JDK y comprueba que javac este en PATH.
    exit /b 1
)
where jar >nul 2>nul
if errorlevel 1 (
    echo Error: no se encontro la herramienta jar del JDK.
    exit /b 1
)
if not exist "reina.png" (
    echo Error: no se encontro reina.png en la carpeta del proyecto.
    exit /b 1
)

if not exist "build\classes" mkdir "build\classes"
javac --release 17 -encoding UTF-8 -d "build\classes" "NReinas.java"
if errorlevel 1 (
    echo Error: no se pudo compilar NReinas.java.
    exit /b 1
)

copy /Y "reina.png" "build\classes\reina.png" >nul
if errorlevel 1 (
    echo Error: no se pudo copiar reina.png a la carpeta de compilacion.
    exit /b 1
)

jar --create --file "build\NReinas.jar" --main-class NReinas -C "build\classes" .
if errorlevel 1 (
    echo Error: no se pudo crear build\NReinas.jar.
    exit /b 1
)

echo Compilacion correcta: build\NReinas.jar
exit /b 0
