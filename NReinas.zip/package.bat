@echo off
setlocal
cd /d "%~dp0"

call build.bat
if errorlevel 1 exit /b 1

if not exist "dist" mkdir "dist"

powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference = 'Stop'; Add-Type -AssemblyName System.IO.Compression; Add-Type -AssemblyName System.IO.Compression.FileSystem; $zipPath = Join-Path (Get-Location) 'dist\NReinas.zip'; if (Test-Path -LiteralPath $zipPath) { Remove-Item -LiteralPath $zipPath -Force }; $archive = [System.IO.Compression.ZipFile]::Open($zipPath, [System.IO.Compression.ZipArchiveMode]::Create); try { foreach ($file in @('NReinas.java','reina.png','build.bat','run.bat','package.bat','README.md')) { [System.IO.Compression.ZipFileExtensions]::CreateEntryFromFile($archive, (Join-Path (Get-Location) $file), $file, [System.IO.Compression.CompressionLevel]::Optimal) | Out-Null }; [System.IO.Compression.ZipFileExtensions]::CreateEntryFromFile($archive, (Join-Path (Get-Location) 'build\NReinas.jar'), 'build/NReinas.jar', [System.IO.Compression.CompressionLevel]::Optimal) | Out-Null } finally { $archive.Dispose() }; exit 0"
if errorlevel 1 (
    echo Error: no se pudo crear dist\NReinas.zip.
    exit /b 1
)

echo ZIP listo: dist\NReinas.zip
exit /b 0
