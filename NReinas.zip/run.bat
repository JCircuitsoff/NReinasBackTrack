@echo off
setlocal
cd /d "%~dp0"

if not exist "build\NReinas.jar" (
    call build.bat
    if errorlevel 1 exit /b 1
)

where java >nul 2>nul
if errorlevel 1 (
    echo Error: se necesita Java 17 o posterior para ejecutar la aplicacion.
    echo Instala un JRE o JDK y comprueba que java este en PATH.
    exit /b 1
)

java -jar "build\NReinas.jar"
if errorlevel 1 (
    echo Error: no se pudo iniciar la aplicacion.
    exit /b 1
)
